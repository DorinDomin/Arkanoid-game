package input;

import levels.LevelInformation;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

/**
 * The SetsMap class is in charge of handling the level-set file.
 * objects.
 *
 * @author Dorin Domin
 */
public class SetsMap {
    // Fields
    private final HashMap<String, ArrayList<LevelInformation>> sets;
    private final HashMap<String, String> desc;
    private final String path;

    /**
     * Constructor.
     *
     * @param s String.
     */
    public SetsMap(String s) {
        this.path = s;
        this.sets = new HashMap<>();
        this.desc = new HashMap<>();
    }

    /**
     * Builds relevant maps from member File path.
     *
     * @return true if successful, false otherwise.
     */
    public Boolean create() {
        InputStream inputS = ClassLoader.getSystemClassLoader().getResourceAsStream(this.path);
        if (inputS == null) {
            return false;
        }
        LinesGenerator linesGenerator = new LinesGenerator();
        LevelSpecificationReader levelsR = new LevelSpecificationReader();
        InputStreamReader reader = new InputStreamReader(inputS), pathReader = null;
        ArrayList<String> oddLines = linesGenerator.oddLines(reader);
        inputS = ClassLoader.getSystemClassLoader().getResourceAsStream(this.path);
        reader = new InputStreamReader(inputS);
        ArrayList<String> evenLines = linesGenerator.evenLines(reader);
        // Check for valid sets
        if (oddLines == null || evenLines == null || oddLines.size() != evenLines.size()) {
            return false;
        }
        // Update relevant maps by sets
        for (int i = 0; i < oddLines.size(); i++) {
            String[] data = oddLines.get(i).split(":");
            this.desc.put(data[0], data[1]);
            inputS = ClassLoader.getSystemClassLoader().getResourceAsStream(evenLines.get(i));
            if (inputS == null) {
                return null;
            }
            pathReader = new InputStreamReader(inputS);
            ArrayList<LevelInformation> levels = (ArrayList<LevelInformation>) levelsR.fromReader(pathReader);
            this.sets.put(data[0], levels);
            // If no levels exits
            if (levels == null) {
                this.sets.clear();
                this.desc.clear();
                return false;
            }
        }
        try {
            // Close
            if (reader != null) {
                reader.close();
            }
            if (pathReader != null) {
                pathReader.close();
            }
            if (inputS != null) {
                inputS.close();
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return true;
        }
    }

    /**
     * Getter for keys.
     *
     * @return keys.
     */
    public ArrayList<String> getKeys() {
        // If no keys exists
        if (this.path.isEmpty()) {
            return null;
        }
        Set<String> s = this.desc.keySet();
        ArrayList<String> k = new ArrayList<String>();
        k.addAll(s);
        return k;

    }

    /**
     * Getter for sets.
     *
     * @return sets.
     */
    public ArrayList<ArrayList<LevelInformation>> getSets() {
        // If no sets exists
        if (this.sets.isEmpty()) {
            return null;
        }
        // If no keys exists
        ArrayList<String> k = getKeys();
        if (k == null) {
            return null;
        }
        ArrayList<ArrayList<LevelInformation>> s = new ArrayList<ArrayList<LevelInformation>>();
        for (int i = 0; i < k.size(); i++) {
            s.add(this.sets.get(k.get(i)));
        }
        return s;
    }

    /**
     * Getter for desc.
     *
     * @return sets.
     */
    public ArrayList<String> getDesc() {
        // Case empty
        if (this.desc.isEmpty()) {
            return null;
        }
        // If no keys exists
        ArrayList<String> k = getKeys();
        if (k == null) {
            return null;
        }
        ArrayList<String> s = new ArrayList<String>();
        for (int i = 0; i < k.size(); i++) {
            s.add(this.desc.get(k.get(i)));
        }
        return s;
    }
}
