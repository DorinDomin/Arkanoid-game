package input;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;

/**
 * The LinesGenerator class is in charge of reading
 * file data.
 *
 * @author Dorin Domin
 */
public class LinesGenerator {
    /**
     * Generates a List with all Lines from inputed file.
     *
     * @param r java.io.reader.
     * @return list of lines.
     */
    public ArrayList<String> get(Reader r) {
        BufferedReader buffer = null;
        ArrayList<String> data = new ArrayList<String>();
        try {
            // Use buffer to read lines
            buffer = new BufferedReader(r);
            String line = buffer.readLine();
            // Check for relevat lines
            while (line != null) {
                if (!line.isEmpty()) {
                    char check = line.charAt(0);
                    if (check != '#' && check != '\t' && check != ' ' && check != '\n' && check != '\r') {
                        data.add(line);
                    }
                }
                line = buffer.readLine();
            }
            return data;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                // Close
                if (buffer != null) {
                    buffer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Generates lines List from start and end indexes.
     *
     * @param lines list of lines.
     * @param start integer index.
     * @param end   integer index.
     * @return list of lines.
     */
    public ArrayList<String> getLevelLines(ArrayList<String> lines, int start, int end) {
        ArrayList<String> result = new ArrayList<String>();
        if (!lines.get(start).equals("START_LEVEL") || !lines.get(end).equals("END_LEVEL")) {
            return null;
        }
        // Iterate through lines
        for (int i = start + 1; i < end; i++) {
            if (!lines.get(i).isEmpty()) {
                char c = lines.get(i).charAt(0);
                if (c != '#' && c != '\t' && c != ' ' && c != '\n' && c != '\r') {
                    result.add(lines.get(i));
                }
            }
        }
        return result;
    }

    /**
     * Generates lines List from start and end indexes.
     *
     * @param l     list of lines.
     * @param start integer index.
     * @param end   integer index.
     * @return list of lines.
     */
    public ArrayList<String> getBlocksLines(ArrayList<String> l, int start, int end) {
        ArrayList<String> result = new ArrayList<String>();
        if (!l.get(start).equals("START_BLOCKS") || !l.get(end).equals("END_BLOCKS")) {
            return null;
        }
        // Iterate through lines
        for (int i = start + 1; i < end; i++) {
            if (!l.get(i).isEmpty()) {
                char c = l.get(i).charAt(0);
                if (c != '#' && c != '\t' && c != ' ' && c != '\n' && c != '\r') {
                    result.add(l.get(i));
                }
            }
        }
        return result;
    }

    /**
     * Generates a List with all odd numbered Lines from inputed file.
     *
     * @param r java.io.reader.
     * @return list of String.
     */
    public ArrayList<String> oddLines(Reader r) {
        BufferedReader buffer = null;
        ArrayList<String> data = new ArrayList<String>();
        try {
            // Use buffer to read lines
            buffer = new BufferedReader(r);
            String line = buffer.readLine();
            int index = 1;
            // Check for relevant lines
            while (line != null) {
                if (!line.isEmpty() && index % 2 == 1) {
                    char check = line.charAt(0);
                    if (check != '#' && check != '\t' && check != ' ' && check != '\n' && check != '\r') {
                        data.add(line);
                    }
                }
                index++;
                line = buffer.readLine();
            }
            return data;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (buffer != null) {
                    buffer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }

    /**
     * Generates a List with all even numbered Lines from inputed file.
     *
     * @param r java.io.reader.
     * @return list of String.
     */
    public ArrayList<String> evenLines(Reader r) {
        BufferedReader buffer = null;
        ArrayList<String> data = new ArrayList<String>();
        try {
            // Use buffer to read lines
            buffer = new BufferedReader(r);
            String line = buffer.readLine();
            int index = 1;
            // Check for relevant lines
            while (line != null) {
                if (!line.isEmpty() && index % 2 == 0) {
                    char check = line.charAt(0);
                    if (check != '#' && check != '\t' && check != ' ' && check != '\n' && check != '\r') {
                        data.add(line);
                    }
                }
                index++;
                line = buffer.readLine();
            }
            return data;
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (buffer != null) {
                    buffer.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

    }
}
