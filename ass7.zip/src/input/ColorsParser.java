package input;

import java.awt.Color;
import java.util.HashMap;

/**
 * ColorsParser class is in charge of converting Strings to colors.
 *
 * @author Dorin Domin
 */
public class ColorsParser {
    /**
     * Retrun HashMap of colors.
     *
     * @return HashMap of colors.
     */
    private HashMap<String, Color> colors() {
        HashMap<String, java.awt.Color> color = new HashMap<String, java.awt.Color>();
        color.put("red", Color.RED);
        color.put("Red", Color.RED);
        color.put("RED", Color.RED);
        color.put("white", Color.WHITE);
        color.put("White", Color.WHITE);
        color.put("WHITE", Color.WHITE);
        color.put("yellow", Color.YELLOW);
        color.put("Yellow", Color.YELLOW);
        color.put("YELLOW", Color.YELLOW);
        color.put("pink", Color.PINK);
        color.put("Pink", Color.PINK);
        color.put("PINK", Color.PINK);
        color.put("orange", Color.ORANGE);
        color.put("Orange", Color.ORANGE);
        color.put("ORANGE", Color.ORANGE);
        color.put("green", Color.GREEN);
        color.put("Green", Color.GREEN);
        color.put("GREEN", Color.GREEN);
        color.put("lightGray", Color.LIGHT_GRAY);
        color.put("LIGHTGRAY", Color.LIGHT_GRAY);
        color.put("LightGray", Color.LIGHT_GRAY);
        color.put("Lightgray", Color.LIGHT_GRAY);
        color.put("lightgray", Color.LIGHT_GRAY);
        color.put("gray", Color.GRAY);
        color.put("Gray", Color.GRAY);
        color.put("GRAY", Color.GRAY);
        color.put("cyan", Color.CYAN);
        color.put("Cyan", Color.CYAN);
        color.put("CYAN", Color.CYAN);
        color.put("blue", Color.BLUE);
        color.put("Blue", Color.BLUE);
        color.put("BLUE", Color.BLUE);
        color.put("black", Color.BLACK);
        color.put("Black", Color.BLACK);
        color.put("BLACK", Color.BLACK);
        return color;
    }

    /**
     * Convert s to color.
     *
     * @param s String.
     * @return color.
     */
    public java.awt.Color colorFromString(String s) {
        // Case color is RGB
        if (s.startsWith("RGB(")) {
            String col = s.substring(4);
            int r, g, b;
            StringBuilder str = new StringBuilder();
            int i = 0;
            // Convert RGB numbers to color
            while (col.charAt(i) != ',') {
                char c = col.charAt(i);
                if (!Character.isDigit(c)) {
                    return null;
                }
                str.append(c);
                i++;
            }
            i++;
            // Convert RGB numbers to color
            r = Integer.parseInt(str.toString());
            str = new StringBuilder();
            while (col.charAt(i) != ',') {
                char c = col.charAt(i);
                if (!Character.isDigit(c)) {
                    return null;
                }
                str.append(c);
                i++;
            }
            i++;
            // Convert RGB numbers to color
            g = Integer.parseInt(str.toString());
            str = new StringBuilder();
            while (col.charAt(i) != ')') {
                char c = col.charAt(i);
                if (!Character.isDigit(c)) {
                    return null;
                }
                str.append(c);
                i++;
            }
            b = Integer.parseInt(str.toString());
            return new Color(r, g, b);
        }
        // Check if converted String is color from list
        HashMap<String, Color> colors = this.colors();
        if (colors.containsKey(s)) {
            return colors.get(s);
        }
        return null;
    }
}
