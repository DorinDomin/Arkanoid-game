package input;

import java.awt.Color;
import java.awt.Image;
import java.io.InputStream;
import java.io.InputStreamReader;

import biuoop.DrawSurface;
import levels.LevelInformation;
import sprites.Block;
import sprites.Sprite;
import geometry.Velocity;

import java.util.ArrayList;
import java.util.List;

/**
 * The LevelSpecificationReader class is getting
 * a file name and returns a list of LevelInformation
 * objects.
 *
 * @author Dorin Domin
 */
public class LevelSpecificationReader {
    public static final int WIDTH = 800;
    public static final int HIEGHT = 600;
    public static final int BOUNDRY = 24;

    /**
     * Generates list of Levels from inputed stream.
     *
     * @param reader java.io.reader.
     * @return list of level Information.
     */
    public List<LevelInformation> fromReader(java.io.Reader reader) {
        LinesGenerator lineGen = new LinesGenerator();
        ArrayList<String> lines = lineGen.get(reader);
        ArrayList<LevelInformation> levels = new ArrayList<LevelInformation>();
        // Check for valid lines
        if (lines == null || lines.isEmpty() || !lines.get(0).equals("START_LEVEL")) {
            return null;
        }
        // Get the end of file
        for (int k = 0; k < lines.size(); k++) {
            int start = k;
            while (k < lines.size() && !lines.get(k).equals("END_LEVEL")) {
                k++;
            }
            // Reached the end of file without reading "END_LEVEL".
            if (k == lines.size()) {
                return null;
            }
            ArrayList<String> levelLines = lineGen.getLevelLines(lines, start, k);
            if (levelLines == null || levelLines.isEmpty()) {
                return null;
            }
            LevelInformation level = this.levelGenerator(levelLines);
            if (level != null) {
                levels.add(level);
            }
        }
        return levels;
    }

    /**
     * Generates level from inputed lines List.
     *
     * @param lines list of lines.
     * @return level Info.
     */
    private LevelInformation levelGenerator(ArrayList<String> lines) {
        java.awt.Image curImage = null;
        ImageGetter imageGetter = new ImageGetter();
        java.awt.Color curColor = null;
        ColorsParser colorP = new ColorsParser();
        Sprite background = null;
        String name = null;
        BlocksFromSymbolsFactory factory = null;
        Integer pSpeed = null, pW = null, blX = null, blY = null, rowH = null, blocksN = null;
        ArrayList<Velocity> vel = new ArrayList<Velocity>();
        ArrayList<Block> blocks = new ArrayList<Block>();
        for (int i = 0; i < lines.size(); i++) {
            String str = lines.get(i);
            // Handle level_name data
            if (str.startsWith("level_name")) {
                name = str.split(":")[1];
            } else if (str.startsWith("ball_velocities")) {
                // Handle ball_velocities data
                String[] s = str.split(":")[1].split(" ");
                for (int j = 0; j < s.length; j++) {
                    String[] velocity = s[j].split(",");
                    try {
                        int angle = Integer.parseInt(velocity[0]);
                        int speed = Integer.parseInt(velocity[1]);
                        Velocity v = Velocity.fromAngleAndSpeed(angle, speed);
                        vel.add(v);
                    } catch (NumberFormatException e) {
                        return null;
                    }
                }
            } else if (str.startsWith("background")) {
                // Handle background data
                String[] arr = str.split(":");
                String bg = arr[1];
                // Handle image as background
                if (bg.startsWith("image(")) {
                    String im = bg.substring(6);
                    curImage = imageGetter.load(im.substring(0, im.length() - 1));
                    if (curImage == null) {
                        return null;
                    }
                } else if (bg.startsWith("color(")) {
                    // Handle color as background
                    String col = bg.substring(6);
                    curColor = colorP.colorFromString(col.substring(0, col.length() - 1));
                    if (curColor == null) {
                        return null;
                    }
                } else {
                    return null;
                }
                if (curImage != null) {
                    final Image factoryImage = curImage;
                    background = new Sprite() {
                        public void drawOn(DrawSurface d) {
                            d.drawImage(0, BOUNDRY, factoryImage);
                        }

                        public void timePassed(double dt) {
                        }
                    };
                }
                if (curColor != null) {
                    final Color factoryColor = curColor;
                    background = new Sprite() {
                        public void drawOn(DrawSurface d) {
                            d.setColor(factoryColor);
                            d.fillRectangle(0, BOUNDRY, WIDTH, HIEGHT);
                        }

                        public void timePassed(double dt) {
                        }
                    };
                }
            } else if (str.startsWith("paddle_speed")) { // Handle paddle_speed data
                String num = str.split(":")[1];
                try {
                    pSpeed = Integer.parseInt(num);
                } catch (NumberFormatException e) {
                    return null;
                }
            } else if (str.startsWith("paddle_width")) { // Handle paddle_width data
                String num = str.split(":")[1];
                try {
                    pW = Integer.parseInt(num);
                } catch (NumberFormatException e) {
                    return null;
                }
            } else if (str.startsWith("blocks_start_x")) { // Handle blocks_start_x data
                try {
                    blX = Integer.parseInt(str.split(":")[1]);
                } catch (NumberFormatException e) {
                    return null;
                }
            } else if (str.startsWith("blocks_start_y")) { // Handle blocks_start_y data
                try {
                    blY = Integer.parseInt(str.split(":")[1]);
                } catch (NumberFormatException e) {
                    return null;
                }
            } else if (str.startsWith("row_height")) { // Handle row_height data
                try {
                    rowH = Integer.parseInt(str.split(":")[1]);
                } catch (NumberFormatException e) {
                    return null;
                }
            } else if (str.startsWith("num_blocks")) { // Handle num_blocks data
                try {
                    blocksN = Integer.parseInt(str.split(":")[1]);
                } catch (NumberFormatException e) {
                    return null;
                }
            } else if (str.startsWith("block_definitions")) { // Handle block_definitions data
                InputStream inputS = ClassLoader.getSystemClassLoader().getResourceAsStream(str.split(":")[1]);
                InputStreamReader r = new InputStreamReader(inputS);
                factory = BlocksDefinitionReader.fromReader(r);
                if (factory == null) {
                    return null;
                }
            } else if (str.equals("START_BLOCKS")) {
                int k = i + 1;
                while (k < lines.size() && !lines.get(k).equals("END_BLOCKS")) {
                    ++k;
                }
                if (k == lines.size()) {
                    return null;
                }
                // Handle block's lines
                LinesGenerator linesGenerator = new LinesGenerator();
                ArrayList<String> blockLines = linesGenerator.getBlocksLines(lines, i, k);
                if (blockLines == null || blX == null || rowH == null || blY == null || factory == null) {
                    return null;
                }
                int fHeight = rowH.intValue();
                int x = blX.intValue();
                int y = blY.intValue();
                blocks = createBlocksL(blockLines, fHeight, x, y, factory);
                break;
            } else {
                return null;
            }
        }
        if (pSpeed == null || pW == null || blX == null || blY == null || rowH == null
                || blocksN == null || background == null
                || name == null || blocks == null) { // Check for empty data
            return null;
        }
        return createLevel(pSpeed, pW, blocksN, name, background, blocks, vel);
    }

    /**
     * Create a new level by given data.
     *
     * @param ps     integer representing paddle's speed.
     * @param pw     integer representing paddle's width.
     * @param bn     integer representing num of blocks in level.
     * @param n      String representing level's name.
     * @param bg     Sprite representing level's background.
     * @param blocks list of blocks.
     * @param v      list of velocities.
     * @return level information.
     */
    private static LevelInformation genLevel(Integer ps, Integer pw, Integer bn, String n, Sprite bg,
                                             ArrayList<Block> blocks, ArrayList<Velocity> v) {
        // Create a new level containing all given data
        LevelInformation level = new LevelInformation() {
            public int numberOfBalls() {
                return v.size();
            }

            public List<Velocity> initialBallVelocities() {
                return v;
            }

            public int paddleSpeed() {
                return ps.intValue();
            }

            public int paddleWidth() {
                return pw.intValue();
            }

            public String levelName() {
                return n;
            }

            public Sprite getBackground() {
                return bg;
            }

            public List<Block> blocks() {
                return blocks;
            }

            public int numberOfBlocksToRemove() {
                return bn;
            }
        };
        return level;
    }

    /**
     * Create a list of blocks out of given block lines.
     *
     * @param blockLines file's block desc.
     * @param rowH       integer representing row height between evey block line.
     * @param x          integer representing x location for block.
     * @param y          integer representing y location for block.
     * @param bfsf       block factory.
     * @return list of blocks.
     */
    private ArrayList<Block> createBlocksL(ArrayList<String> blockLines, int rowH, int x, int y,
                                           BlocksFromSymbolsFactory bfsf) {
        ArrayList<Block> result = new ArrayList<Block>();
        int yLoc = y;
        // Iterates trough block-lines
        for (int i = 0; i < blockLines.size(); i++) {
            yLoc += i * rowH;
            String currentLine = blockLines.get(i);
            int xLoc = x;
            // Iterates trough current line
            for (int j = 0; j < currentLine.length(); j++) {
                Character symbol = currentLine.charAt(j);
                // Check if current char is a block-symbol
                if (bfsf.isBlockSymbol(symbol.toString())) {
                    // Create new block and update location
                    Block block = bfsf.getBlock(symbol.toString(), xLoc, yLoc);
                    xLoc += block.getCollisionRectangle().getWidth();
                    result.add(block);
                } else if (bfsf.isSpaceSymbol(symbol.toString())) {
                    // Check if current char is a block-symbol and update location if need
                    xLoc += bfsf.getSpaceWidth(symbol.toString());
                } else {
                    return null;
                }
            }
            yLoc = y;
        }
        return result;
    }

    /**
     * Hundle block lines in file.
     *
     * @param pSpeed     Integer.
     * @param pW         Integer.
     * @param blocksN    Integer.
     * @param name       Integer.
     * @param background Integer.
     * @param blocks     Integer.
     * @param vel        Integer.
     * @return list of blocks.
     */
    private static LevelInformation createLevel(Integer pSpeed, Integer pW, Integer blocksN, String name,
                                                Sprite background, ArrayList<Block> blocks,
                                                ArrayList<Velocity> vel) {
        // Create new level
        final Integer ps = pSpeed;
        final Integer pw = pW;
        final Integer bn = blocksN;
        final String finalN = name;
        final Sprite finalBack = background;
        final ArrayList<Block> b = blocks;
        final ArrayList<Velocity> v = vel;
        LevelInformation level = genLevel(ps, pw, bn, finalN, finalBack, b, v);
        return level;
    }
}
