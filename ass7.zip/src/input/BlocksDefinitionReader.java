package input;

import java.awt.Color;
import java.awt.Image;
import java.util.ArrayList;
import java.util.HashMap;

import geometry.Point;
import sprites.Block;

/**
 * The BlocksDefinitionReader class is in charge of reading a block-definitions file
 * and returning a BlocksFromSymbolsFactory object.
 *
 * @author Dorin Domin
 */
public class BlocksDefinitionReader {
    /**
     * Creates Block Factory from inputed File stream.
     * If invalid input or fails, returns null.
     *
     * @param reader jav.io.reader.
     * @return Blocks Factory.
     */
    public static BlocksFromSymbolsFactory fromReader(java.io.Reader reader) {
        BlocksFromSymbolsFactory blockF = new BlocksFromSymbolsFactory();
        LinesGenerator lg = new LinesGenerator();
        ArrayList<String> lines = lg.get(reader);
        ColorsParser colorP = new ColorsParser();
        ImageGetter imageG = new ImageGetter();
        HashMap<String, Integer> numDef = new HashMap<>();
        HashMap<String, String> strDef = new HashMap<>();
        String factKey = null;
        Integer width = null, height = null, hitPoints = null;
        java.awt.Color color = null, stroke = null;
        java.awt.Image img = null;
        HashMap<Integer, java.awt.Color> cols = new HashMap<Integer, java.awt.Color>();
        HashMap<Integer, java.awt.Image> imgs = new HashMap<Integer, java.awt.Image>();
        if (lines == null || lines.isEmpty()) {
            return null;
        }
        int len = lines.size();
        for (int i = 0; i < len; i++) { // Iterates through file's lines
            String str = lines.get(i);
            if (str.startsWith("default")) { // Default values in txt
                String[] data = str.split(" ");
                for (int k = 1; k < data.length; k++) {
                    try {
                        numDef.put(data[k].split(":")[0], Integer.parseInt(data[k].split(":")[1]));
                    } catch (NumberFormatException n) {
                        strDef.put(data[k].split(":")[0], data[k].split(":")[1]);
                    }
                }
            } else if (str.startsWith("bdef")) { // Block definitions
                String[] data = str.split(" ");
                for (int k = 1; k < data.length; k++) {
                    String[] arr = data[k].split(":");
                    if (arr[0].equals("symbol")) {
                        if (arr[1].length() != 1) {
                            return null;
                        }
                        factKey = arr[1];
                    } else if (arr[0].equals("width")) {
                        try {
                            width = Integer.parseInt(arr[1]);
                        } catch (NumberFormatException n) {
                            return null;
                        }
                    } else if (arr[0].equals("height")) {
                        try {
                            height = Integer.parseInt(arr[1]);
                        } catch (NumberFormatException n) {
                            return null;
                        }
                    } else if (arr[0].equals("hit_points")) {
                        try {
                            hitPoints = Integer.parseInt(arr[1]);
                        } catch (NumberFormatException n) {
                            return null;
                        }
                    } else if (arr[0].equals("stroke")) {
                        if (arr[1].startsWith("color(")) {
                            stroke = colorP.colorFromString((arr[1].substring(6)).substring(0,
                                    (arr[1].substring(6)).length() - 1));
                            if (stroke == null) {
                                return null;
                            }
                        } else {
                            return null;
                        }
                    } else if (arr[0].equals("fill")) {
                        if (arr[1].startsWith("image")) {
                            img = imageG.load((arr[1].substring(6)).substring(0, (arr[1].substring(6)).length() - 1));
                            if (img == null) {
                                return null;
                            }
                            imgs.put(-1, img);

                        } else if (arr[1].startsWith("color(")) {
                            String c = arr[1].substring(6);
                            color = colorP.colorFromString(c.substring(0, c.length() - 1));
                            if (color == null) {
                                return null;
                            }
                            cols.put(-1, color);
                        } else {
                            return null;
                        }
                    } else if (arr[0].startsWith("fill-")) {
                        try {
                            int key = Integer.parseInt(arr[0].split("-")[1]);
                            if (arr[1].startsWith("image(")) {
                                String name = arr[1].substring(6);
                                if (imageG.load(name.substring(0, name.length() - 1)) == null) {
                                    return null;
                                }
                                imgs.put(key, imageG.load(name.substring(0, name.length() - 1)));
                            } else if (arr[1].startsWith("color(")) {
                                String c = arr[1].substring(6);
                                color = colorP.colorFromString(c.substring(0, c.length() - 1));
                                if (color == null) {
                                    return null;
                                }
                                cols.put(key, color);
                            } else {
                                return null;
                            }
                        } catch (NumberFormatException e) {
                            return null;
                        }
                    }
                }
                width = checkForNull(width, numDef, "width");
                height = checkForNull(height, numDef, "height");
                hitPoints = checkForNull(hitPoints, numDef, "hit_points");
                stroke = checkForNullC(stroke, strDef, "stroke", colorP);
                if ((width == null) || (height == null) || (hitPoints == null) || (stroke == null)) {
                    return null;
                }
                if (!imgs.containsKey(-1) && !cols.containsKey(-1) && !imgs.containsKey(1) && !cols.containsKey(1)) {
                    if (strDef.containsKey("fill")) {
                        if (colorP.colorFromString(strDef.get("fill")) != null) {
                            cols.put(-1, colorP.colorFromString(strDef.get("fill")));
                        } else if (imageG.load(strDef.get("fill")) != null) {
                            imgs.put(-1, imageG.load(strDef.get("fill")));
                        } else {
                            return null;
                        }
                    } else {
                        return null;
                    }
                }
                if (factKey == null) {
                    return null;
                }
                blockF.addBlkCreator(factKey, blockCreator(width, height, hitPoints, stroke, cols, imgs));
                width = null;
                height = null;
                hitPoints = null;
                stroke = null; // Reset vals
                cols = new HashMap<Integer, Color>();
                imgs = new HashMap<Integer, Image>();
            } else if (str.startsWith("sdef")) { // Handle other data in file-Space definitions
                blockF = hundleSdef(str, factKey, blockF);
                if (blockF == null) {
                    return null;
                }
                factKey = null;
            }
        }
        return blockF;
    }

    /**
     * Generates BlockCreator.
     *
     * @param wid    width.
     * @param hi     height.
     * @param hitP   num of hit points.
     * @param s      color.
     * @param colors color map.
     * @param images image map.
     * @return BlockCreator.
     */
    private static BlockCreator blkCreatort(Integer wid, Integer hi, Integer hitP, Color s,
                                            HashMap<Integer, java.awt.Color> colors,
                                            HashMap<Integer, java.awt.Image> images) {
        // Create a new Block Creator and override create method
        BlockCreator blockC = new BlockCreator() {
            @Override
            public Block create(int xpos, int ypos) {
                Block block = new Block(new Point(xpos, ypos), wid.intValue(), hi.intValue(),
                        s, hitP.intValue());
                block.setMapClr(colors);
                block.setMapImg(images);
                return block;
            }
        };
        return blockC;
    }

    /**
     * Check for null vals.
     *
     * @param val    Integer.
     * @param numDef HashMap.
     * @param str    String.
     * @return Integer.
     */
    private static Integer checkForNull(Integer val, HashMap<String, Integer> numDef, String str) {
        Integer newVal = val;
        if (val == null) { // Handle an empty data
            if (numDef.containsKey(str)) {
                newVal = numDef.get(str);
            } else {
                return null;
            }
        }
        return newVal;
    }

    /**
     * Check for null vals.
     *
     * @param val    Color.
     * @param strDef HashMap.
     * @param str    String.
     * @param colorP Color Parser.
     * @return color.
     */
    private static Color checkForNullC(Color val, HashMap<String, String> strDef, String str, ColorsParser colorP) {
        Color newVal = val;
        if (val == null) { // Handle an empty data
            if (strDef.containsKey(str)) {
                String c = strDef.get(str);
                newVal = colorP.colorFromString(c.substring(6, c.length() - 1));
            }
        }
        return newVal;
    }

    /**
     * Create a new block Creator according to given vals.
     *
     * @param width     Integer.
     * @param height    Integer.
     * @param hitPoints Integer.
     * @param stroke    Color.
     * @param cols      HashMap.
     * @param imgs      HashMap.
     * @return BlockCreator.
     */
    private static BlockCreator blockCreator(Integer width, Integer height, Integer hitPoints, Color stroke,
                                             HashMap<Integer, java.awt.Color> cols,
                                             HashMap<Integer, java.awt.Image> imgs) {
        final Integer wid = width;
        final Integer hi = height;
        final Integer hits = hitPoints;
        final Color stro = stroke;
        final HashMap<Integer, java.awt.Color> fCols = cols;
        final HashMap<Integer, java.awt.Image> fImgs = imgs;
        BlockCreator blockC = blkCreatort(wid, hi, hits, stro, fCols, fImgs); // Create new block creator
        return blockC;
    }

    /**
     * Hundle Sdef data in file.
     *
     * @param str     String.
     * @param factKey String.
     * @param blockF  BlocksFromSymbolsFactory.
     * @return BlocksFromSymbolsFactory.
     */
    private static BlocksFromSymbolsFactory hundleSdef(String str, String factKey, BlocksFromSymbolsFactory blockF) {
        String[] data = str.split(" ");
        for (int k = 1; k < data.length; k++) {
            String[] arr = data[k].split(":");
            if (arr[0].equals("symbol")) {
                if (arr[1].length() != 1) {
                    return null;
                }
                factKey = arr[1];
            } else if (arr[0].startsWith("width")) {
                try {
                    int w = Integer.parseInt(arr[1]);
                    blockF.addSpc(factKey, w);
                } catch (NumberFormatException n) {
                    return null;
                }
            }
        }
        return blockF;
    }
}
