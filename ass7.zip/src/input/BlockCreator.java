package input;

import sprites.Block;

/**
 * BlockCreator is an interface of a factory-object that is used for creating blocks.
 *
 * @author Dorin Domin
 */
public interface BlockCreator {
    /**
     * Create a block at the specified location.
     *
     * @param xpos x location.
     * @param ypos y location.
     * @return new Block in x,y location.
     */
    Block create(int xpos, int ypos);
}
