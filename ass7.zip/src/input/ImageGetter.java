package input;

import javax.imageio.ImageIO;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;

/**
 * ImageGetter class is in charge of taking image out of a given path.
 *
 * @author Dorin Domin
 */
public class ImageGetter {
    /**
     * Loads Image from inputed file path.
     *
     * @param path String.
     * @return Image.
     */
    public Image load(String path) {
        BufferedImage buffer = null;

        try {
            // Load image from path
            InputStream cL = ClassLoader.getSystemClassLoader().getResourceAsStream(path);
            buffer = ImageIO.read(cL);
            return buffer;
        } catch (IOException e) {
            return null;
        }
    }
}
