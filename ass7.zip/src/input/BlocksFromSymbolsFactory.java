package input;

import sprites.Block;

import java.util.HashMap;
import java.util.Map;

/**
 * Implementation of BlocksFromSymbolsFactory class.
 *
 * @author Dorin Domin
 */
public class BlocksFromSymbolsFactory {
    private Map<String, Integer> spacerWidths = new HashMap<String, Integer>();
    private Map<String, BlockCreator> blockCreators = new HashMap<>();

    /**
     * Returns true if 's' is a valid space symbol.
     *
     * @param s String.
     * @return true if s is spaceSymbol, false otherwise.
     */
    public boolean isSpaceSymbol(String s) {
        if (this.spacerWidths.containsKey(s)) {
            return true;
        }
        return false;
    }

    /**
     * Returns true if 's' is a valid block symbol.
     *
     * @param s String.
     * @return true if s is spaceSymbol, false otherwise.
     */
    public boolean isBlockSymbol(String s) {
        if (this.blockCreators.containsKey(s)) {
            return true;
        }
        return false;
    }

    /**
     * Return a block according to the definitions associated
     * with symbol s. The block will be located at position (xpos, ypos).
     *
     * @param s String.
     * @param x integer.
     * @param y integer.
     * @return Block.
     */
    public Block getBlock(String s, int x, int y) {
        return this.blockCreators.get(s).create(x, y);

    }

    /**
     * Returns the width in pixels associated with the given spacer-symbol.
     *
     * @param s String.
     * @return integer.
     */
    public int getSpaceWidth(String s) {
        return this.spacerWidths.get(s);

    }

    /**
     * Adds blockCreator to factory.
     *
     * @param key String.
     * @param b   BlockCreator.
     */
    public void addBlkCreator(String key, BlockCreator b) {
        this.blockCreators.put(key, b);
    }

    /**
     * Adds spacer to factory.
     *
     * @param key String.
     * @param num integer.
     */
    public void addSpc(String key, Integer num) {
        this.spacerWidths.put(key, num);
    }
}
