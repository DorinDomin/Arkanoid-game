package animations;

import biuoop.DrawSurface;
import geometry.Point;
import sprites.Counter;

import java.awt.Color;

/**
 * Once the game is over, we will display the final score.
 * If the game ended with the player losing all his lives, the end screen should display
 * the message "Game Over. Your score is X" (X being the final score).
 * If the game ended by clearing all the levels, the screen should display
 * "You Win! Your score is X".
 * The "end screen" will persist until the space key is pressed.
 *
 * @author Dorin Domin
 */
public class EndScreen implements Animation {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final Point LOC = new Point(50, 200);
    public static final Point LOC2 = new Point(50, 300);
    public static final int FONT_SIZE = 32;
    // Fields
    private Counter scores;
    private boolean win;
    private boolean stop;

    /**
     * Constructor.
     *
     * @param s       number of scores.
     * @param victory boolean representing if the player won.
     */
    public EndScreen(Counter s, boolean victory) {
        this.scores = s;
        this.win = victory;
        this.stop = false;
    }

    /**
     * Puts one frame on surface.
     *
     * @param d  the game surface.
     * @param dt the difference.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        // Show screen with the result
        if (this.win) {
            d.setColor(new Color(15, 207, 100));
            d.fillRectangle(0, 0, WIDTH, HEIGHT);
            d.setColor(Color.white);
            String str = "You Win! Your score is " + this.scores.getValue();
            d.drawText((int) LOC.getX(), (int) LOC.getY(), str, FONT_SIZE);
        } else {
            d.setColor(Color.red);
            d.fillRectangle(0, 0, WIDTH, HEIGHT);
            d.setColor(Color.white);
            String str = "Game Over. Your score is " + this.scores.getValue();
            d.drawText((int) LOC.getX(), (int) LOC.getY(), str, FONT_SIZE);
        }
        // Close screen when pressing space
        d.setColor(Color.darkGray);
        d.drawText((int) LOC2.getX(), (int) LOC2.getY(), "press space to continue", FONT_SIZE - 4);
    }

    /**
     * Stops Animation.
     *
     * @return true in order to stop the animation,false otherwise.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}
