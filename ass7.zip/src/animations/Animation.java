package animations;

import biuoop.DrawSurface;

/**
 * The Animation is an interface that will be implement by classes that include some animations to run.
 *
 * @author Dorin Domin
 */
public interface Animation {

    /**
     * Puts one frame on surface.
     *
     * @param d  the game surface.
     * @param dt the difference.
     */
    void doOneFrame(DrawSurface d, double dt);

    /**
     * Stops Animation.
     *
     * @return true in order to stop the animation,false otherwise.
     */
    boolean shouldStop();
}
