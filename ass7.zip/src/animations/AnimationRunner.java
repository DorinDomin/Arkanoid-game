package animations;

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

/**
 * The AnimationRunner takes an Animation object and runs it.
 *
 * @author Dorin Domin
 */
public class AnimationRunner {
    //Fields
    private GUI gui;
    private int framesPerSecond;
    private biuoop.Sleeper sleeper;
    private double dt;

    /**
     * Constructor.
     *
     * @param game   the gui-board of the game.
     * @param frames frames per second.
     */
    public AnimationRunner(GUI game, int frames) {
        this.gui = game;
        this.framesPerSecond = frames;
        this.sleeper = new Sleeper();
        this.dt = (double) 1 / frames;
    }

    /**
     * Run the given animation.
     *
     * @param animation an animation to run.
     */
    public void run(Animation animation) {
        int millisecondsPerFrame = 1000 / this.framesPerSecond;

        while (!animation.shouldStop()) {
            // Timing
            long startTime = System.currentTimeMillis();
            DrawSurface d = gui.getDrawSurface();
            animation.doOneFrame(d, this.dt);
            gui.show(d);
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                this.sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }

    /**
     * Setter for frames per second.
     *
     * @param sec representing the number of frames per second.
     */
    public void setFramesPerSecond(double sec) {
        this.framesPerSecond = (int) sec;
    }

    /**
     * getter for framesPerSecond field.
     *
     * @return **integer**
     */
    public int getFps() {
        return this.framesPerSecond;
    }
}

