package animations;

/**
 * The Menu is an interface that will be used for the general and sub menus.
 *
 * @param <T> generic Type.
 * @author Dorin Domin
 */
public interface Menu<T> extends Animation {
    /**
     * Add selection to Menu.
     *
     * @param key       String.
     * @param message   String.
     * @param returnVal String.
     */
    void addSelection(String key, String message, T returnVal);

    /**
     * Get the current status of Menu.
     *
     * @return Menu object.
     */
    T getStatus();

    /**
     * Add sub menu to current menu.
     *
     * @param key     String.
     * @param message String.
     * @param subMenu Menu.
     */
    void addSubMenu(String key, String message, Menu<T> subMenu);
}
