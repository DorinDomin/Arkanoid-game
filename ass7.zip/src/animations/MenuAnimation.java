package animations;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;
import geometry.Point;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;

/**
 * The MenuAnimation class is used as a general menu viewer.
 *
 * @param <T> generic Type.
 * @author Dorin Domin
 */
public class MenuAnimation<T> implements Menu<T>, Animation {
    public static final int HIEGHT = 600;
    public static final int WIDTH = 800;
    public static final Point HEAD = new Point(290, 100);
    public static final Point KEYS = new Point(320, 270);
    public static final Point NAMES = new Point(KEYS.getX() + 50, KEYS.getY());
    public static final int HEAD_FONT = 50;
    public static final int TASKS_FONT = 22;
    // Fields
    private boolean stop;
    private final biuoop.KeyboardSensor k;
    private final HashMap<String, T> taskMap;
    private final HashMap<String, String> names;
    private String statusKey = "";

    /**
     * Constructor.
     *
     * @param key keyboard sensor.
     */
    public MenuAnimation(KeyboardSensor key) {
        this.k = key;
        this.stop = false;
        this.taskMap = new HashMap<String, T>();
        this.names = new HashMap<String, String>();
    }

    /**
     * Puts one frame on surface.
     *
     * @param d  the game surface.
     * @param dt the difference.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        // Draw heat-title
        d.setColor(Color.DARK_GRAY);
        d.fillRectangle(0, 0, WIDTH, HIEGHT);
        d.setColor(new Color(0x000000));
        d.drawText((int) HEAD.getX() + 2, (int) HEAD.getY(), "Arkanoid", HEAD_FONT);
        d.setColor(new Color(0x8373D0));
        d.drawText((int) HEAD.getX() - 2, (int) HEAD.getY(), "Arkanoid", HEAD_FONT);
        d.setColor(new Color(0x89A2CC));
        d.drawText((int) HEAD.getX() - 6, (int) HEAD.getY(), "Arkanoid", HEAD_FONT);
        // Draw menu's options
        d.setColor(Color.WHITE);
        ArrayList<String> keys = new ArrayList<String>(this.names.keySet());
        int size = keys.size();
        for (int i = 0; i < size; i++) {
            String str = "(" + keys.get(i) + ")";
            d.drawText((int) KEYS.getX(), (int) KEYS.getY() + (25 * i), str, TASKS_FONT);
            d.drawText((int) NAMES.getX(), (int) NAMES.getY() + (25 * i), this.names.get(keys.get(i)), TASKS_FONT);
        }
        // Check if pressed an option
        for (int i = 0; i < size; i++) {
            if (this.k.isPressed(keys.get(i))) {
                this.statusKey = keys.get(i);
                this.stop = true;
                break;
            }
        }
    }

    /**
     * Stops Animation.
     *
     * @return true in order to stop the animation,false otherwise.
     */
    public boolean shouldStop() {
        return this.stop;
    }

    /**
     * Add selection to Menu.
     *
     * @param key       String.
     * @param message   String.
     * @param returnVal String.
     */
    public void addSelection(String key, String message, T returnVal) {
        this.taskMap.put(key, returnVal);
        this.names.put(key, message);
    }

    /**
     * Get the current status of Menu.
     *
     * @return Menu object.
     */
    public T getStatus() {
        if (!this.statusKey.equals("")) {
            return this.taskMap.get(this.statusKey);
        }
        return null;
    }

    /**
     * Add sub menu to current menu.
     *
     * @param key     String.
     * @param message String.
     * @param subMenu Menu.
     */
    public void addSubMenu(String key, String message, Menu<T> subMenu) {

    }


}
