package animations;

import biuoop.DrawSurface;
import game.HighScoresTable;
import game.ScoreInfo;
import geometry.Point;

import java.awt.Color;
import java.util.List;

/**
 * The HighScoresAnimation class is in charge of showing
 * the scores of top players.
 *
 * @author Dorin Domin
 */
public class HighScoresAnimation implements Animation {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final Point HEAD = new Point(50, 50);
    public static final Point HEAD2 = new Point(150, 110);
    public static final Point HEAD3 = new Point(550, HEAD2.getY());
    public static final Point PLAYERS = new Point(HEAD2.getX(), 150);
    public static final Point SCORE = new Point(HEAD3.getX(), PLAYERS.getY());
    public static final Point PRESS = new Point(230, 500);
    public static final int FONT_SIZE = 35;
    public static final int FONT_SIZE2 = 24;

    // Fields
    private HighScoresTable score;
    private boolean stop;

    /**
     * Constructor.
     *
     * @param scores table containing the highest scores in game.
     */
    public HighScoresAnimation(HighScoresTable scores) {
        this.score = scores;
        this.stop = false;
    }

    /**
     * Puts one frame on surface.
     *
     * @param d  the game surface.
     * @param dt the difference.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        // Show screen with the results
        d.setColor(new Color(0xBABABA));
        d.fillRectangle(0, 0, WIDTH, HEIGHT);
        d.setColor(Color.white);
        String str = "High Scores";
        d.setColor(new Color(0x3E3A39));
        d.drawText((int) HEAD.getX() - 2, (int) HEAD.getY() - 2, str, FONT_SIZE);
        d.setColor(new Color(0x9791F0));
        d.drawText((int) HEAD.getX(), (int) HEAD.getY(), str, FONT_SIZE);
        // Show scores
        d.setColor(Color.WHITE);
        d.drawText((int) HEAD2.getX(), (int) HEAD2.getY(), "Player Name", FONT_SIZE2);
        d.drawText((int) HEAD3.getX(), (int) HEAD3.getY(), "Score", FONT_SIZE2);
        double lineY = HEAD3.getY() + 5;
        d.drawLine((int) HEAD2.getX(), (int) lineY, (int) HEAD3.getX() + 100, (int) lineY);
        // Draw scores
        List<ScoreInfo> l = this.score.getHighScores();
        int size = l.size();
        int dif = 25;
        d.setColor(Color.BLACK);
        for (int i = 0; i < size; i++) {
            ScoreInfo inf = l.get(i);
            d.drawText((int) PLAYERS.getX(), (int) (PLAYERS.getY() + (dif * i)), inf.getName(), FONT_SIZE2);
            d.drawText((int) SCORE.getX(), (int) (SCORE.getY() + (dif * i)),
                    String.valueOf(inf.getScore()), FONT_SIZE2);
        }
        // Close screen when pressing space
        d.setColor(new Color(0x3E3A39));
        d.drawText((int) PRESS.getX() - 1, (int) PRESS.getY() - 1, "press space to continue",
                FONT_SIZE - 2);
        d.setColor(new Color(0xA6A11E));
        d.drawText((int) PRESS.getX(), (int) PRESS.getY(), "press space to continue",
                FONT_SIZE - 2);
    }

    /**
     * Stops Animation.
     *
     * @return true in order to stop the animation,false otherwise.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}
