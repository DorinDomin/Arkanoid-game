package animations;

import biuoop.DrawSurface;
import biuoop.KeyboardSensor;

/**
 * The KeyPressStoppableAnimation class is in charge of stopping
 * the game according to keys being pressed.
 *
 * @author Dorin Domin
 */
public class KeyPressStoppableAnimation implements Animation {
    // Fields
    private KeyboardSensor k;
    private String end;
    private Animation animation;
    private boolean stop;
    private boolean isAlreadyPressed;

    /**
     * Constructor.
     *
     * @param sensor    game's keyboard sensor.
     * @param key       to be pressed.
     * @param animation animation to run.
     */
    public KeyPressStoppableAnimation(KeyboardSensor sensor, String key, Animation animation) {
        this.k = sensor;
        this.end = key;
        this.animation = animation;
        this.stop = false;
        this.isAlreadyPressed = true;
    }

    /**
     * Puts one frame on surface.
     *
     * @param d  the game surface.
     * @param dt the difference.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        // Run animation
        this.animation.doOneFrame(d, dt);
        // Check if user pressed the current key
        if (this.k.isPressed(this.end)) {
            if (!this.isAlreadyPressed) {
                this.stop = true;
            }
        } else {
            this.isAlreadyPressed = false;
        }
    }

    /**
     * Stops Animation.
     *
     * @return true in order to stop the animation,false otherwise.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}
