package animations;

import biuoop.DrawSurface;

/**
 * In the game, when we identify the key p being pressed,
 * we start running the PauseScreen animation instead of the Game one.
 * The Game animation will resume as soon as we will return from the PauseScreen animation.
 *
 * @author Dorin Domin
 */
public class PauseScreen implements Animation {
    // Fields
    private boolean stop;

    /**
     * Constructor.
     */
    public PauseScreen() {
        this.stop = false;
    }

    /**
     * Puts one frame on surface.
     *
     * @param d  the game surface.
     * @param dt the difference.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        d.drawText(10, d.getHeight() / 2, "paused -- press space to continue", 32);
    }

    /**
     * Stops Animation.
     *
     * @return true in order to stop the animation,false otherwise.
     */
    public boolean shouldStop() {
        return this.stop;
    }
}
