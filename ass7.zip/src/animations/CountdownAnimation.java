package animations;

import biuoop.DrawSurface;
import geometry.Point;
import sprites.Counter;
import sprites.SpriteCollection;

import java.awt.Color;

/**
 * The CountdownAnimation will display the given gameScreen,
 * for numOfSeconds seconds, and on top of them it will show
 * a countdown from countFrom back to 1, where each number will
 * appear on the screen for (numOfSeconds / countFrom) seconds, before
 * it is replaced with the next one.
 *
 * @author Dorin Domin
 */

public class CountdownAnimation implements Animation {
    public static final Point LOC = new Point(390, 390);
    public static final int FONT_SIZE = 50;
    // Fields
    private double seconds;
    private SpriteCollection screen;
    private Counter counts;
    private boolean running;

    /**
     * Constructor.
     *
     * @param numOfSeconds representing the number of seconds.
     * @param countFrom    representing the start of the counting.
     * @param gameScreen   the games components.
     */
    public CountdownAnimation(double numOfSeconds, int countFrom, SpriteCollection gameScreen) {
        this.seconds = numOfSeconds;
        this.counts = new Counter(countFrom);
        this.screen = gameScreen;
        this.running = true;
    }

    /**
     * Puts one frame on surface.
     *
     * @param d  the game surface.
     * @param dt the difference.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        // Show screen with the game parts.
        this.screen.drawAllOn(d);
        d.setColor(Color.white);
        // Count down and start the game.
        if (this.counts.getValue() == 0) {
            this.running = false;
        } else {
            // Show num of seconds
            d.drawText((int) LOC.getX(), (int) LOC.getY(), String.valueOf(this.counts.getValue()), FONT_SIZE);
            this.counts.decrease(1);
            // Start game after finishing counting
            if (this.counts.getValue() == 0) {
                this.running = false;
            }
        }
    }

    /**
     * Stops Animation.
     *
     * @return true in order to stop the animation,false otherwise.
     */
    public boolean shouldStop() {
        return !this.running;
    }

    /**
     * Getter for num of seconds.
     *
     * @return num of seconds.
     */
    public double getSec() {
        return this.seconds;
    }
}