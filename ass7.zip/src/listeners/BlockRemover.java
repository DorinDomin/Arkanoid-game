package listeners;

import game.GameLevel;
import sprites.Counter;
import sprites.Block;
import sprites.Ball;


/**
 * A listeners.BlockRemover is in charge of removing blocks from the gameLevel, as well as keeping count
 * of the number of blocks that remain.
 *
 * @author Dorin Domin
 */
public class BlockRemover implements HitListener {
    // Fields
    private GameLevel gameLevel;
    private Counter remainingBlocks;

    /**
     * Constructor.
     *
     * @param gameLevel          current gameLevel object.
     * @param removedBlocks number of balls remained in gameLevel.
     */
    public BlockRemover(GameLevel gameLevel, Counter removedBlocks) {
        this.gameLevel = gameLevel;
        this.remainingBlocks = removedBlocks;
    }

    /**
     * Blocks that are hit and reach 0 hit-points should be removed
     * from the gameLevel. Also no more listener is needed.
     *
     * @param beingHit block.
     * @param hitter   ball.
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        if (beingHit.getHitPoints() == 0) {
            beingHit.removeHitListener(this);
            beingHit.removeFromGame(gameLevel);
            remainingBlocks.decrease(1);
        }
    }
}