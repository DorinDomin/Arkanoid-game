package listeners;

import game.GameLevel;
import sprites.Ball;
import sprites.Block;
import sprites.Counter;

/**
 * listeners.BallRemover is a listeners.HitListener that will be in charge of removing balls,
 * and updating an availabe-balls counter.
 *
 * @author Dorin Domin
 */
public class BallRemover implements HitListener {
    // Fields
    private GameLevel gameLevel;
    private Counter remainingBalls;

    /**
     * Constructor.
     *
     * @param gameLevel         current gameLevel.
     * @param removedBalls number of remained balls in gameLevel.
     */
    public BallRemover(GameLevel gameLevel, Counter removedBalls) {
        this.gameLevel = gameLevel;
        this.remainingBalls = removedBalls;
    }

    /**
     * In charge of removing balls, and updating an availabe-balls counter.
     *
     * @param beingHit block.
     * @param hitter   ball.
     */
    @Override
    public void hitEvent(Block beingHit, Ball hitter) {
        hitter.removeFromGame(gameLevel);
        remainingBalls.decrease(1);
    }
}
