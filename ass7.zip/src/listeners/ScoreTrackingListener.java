package listeners;

import sprites.Counter;
import sprites.Block;
import sprites.Ball;

/**
 * The listeners.ScoreTrackingListener updates player's scores
 * when blocks are being hit and removed.
 *
 * @author Dorin Domin
 */
public class ScoreTrackingListener implements HitListener {
    // Fields
    private Counter currentScore;

    /**
     * Constructor.
     *
     * @param scoreCounter integer representing the number of scores.
     */
    public ScoreTrackingListener(Counter scoreCounter) {
        this.currentScore = scoreCounter;
    }

    /**
     * This method is called whenever the beingHit object is hit.
     * The hitter parameter is the sprites.Ball that's doing the hitting.
     *
     * @param beingHit block.
     * @param hitter   ball.
     */
    public void hitEvent(Block beingHit, Ball hitter) {
        // Hitting a block is worth 5 points
        int points = 5;
        //Destroying a block is worth and additional 10 points
        if (beingHit.getHitPoints() == 0) {
            points += 10;
        }
        this.currentScore.increase(points);
    }
}