package game;

import animations.Animation;
import animations.AnimationRunner;
import animations.CountdownAnimation;
import animations.KeyPressStoppableAnimation;
import animations.PauseScreen;
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import geometry.Point;
import listeners.BallRemover;
import listeners.BlockRemover;
import listeners.ScoreTrackingListener;
import levels.LevelInformation;
import sprites.Ball;
import sprites.Block;
import sprites.Collidable;
import sprites.Counter;
import sprites.GameEnvironment;
import sprites.LevelIndicator;
import sprites.LivesIndicator;
import sprites.Paddle;
import sprites.ScoreIndicator;
import sprites.Sprite;
import sprites.SpriteCollection;

import java.awt.Color;

/**
 * The game.GameLevel class that will hold the sprites and the collidables,
 * and will be in charge of the animation.
 *
 * @author Dorin Domin
 */

public class GameLevel implements Animation {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int BOUNDARY_SIZE = 24;
    public static final int BLOCK_LINE_W = 50;
    public static final int BLOCK_LINE_H = 30;
    public static final int FRAMES_FOR_COUNT = 2;
    public static final int COUNT_FROM = 3;
    public static final int RADIUS = 5;
    // Fields
    private GUI gui;
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private Counter blockCounter;
    private Counter ballCounter;
    private Counter score;
    private Counter numberOfLives;
    private Paddle user;
    private AnimationRunner runner;
    private boolean running;
    private KeyboardSensor keyboard;
    private LevelInformation lev;

    /**
     * Constructor.
     *
     * @param level  to run.
     * @param s      KeyboardSensor.
     * @param r      AnimationRunner.
     * @param g      GUI.
     * @param scores counter for player's score.
     * @param live   counter for player's live.
     */
    public GameLevel(LevelInformation level, KeyboardSensor s, AnimationRunner r, GUI g, Counter scores, Counter live) {
        this.gui = g;
        this.sprites = new SpriteCollection();
        this.environment = new GameEnvironment();
        this.blockCounter = new Counter(level.numberOfBlocksToRemove());
        this.ballCounter = new Counter(0);
        this.score = scores;
        this.numberOfLives = live;
        this.user = null;
        this.runner = r;
        this.keyboard = s;
        this.lev = level;
    }

    /**
     * Add collidable to the environment.
     *
     * @param c type collidable.
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * Add to sprites.
     *
     * @param s type sprite.
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * Initialize a new game: create the Blocks and sprites.Ball (and sprites.Paddle)
     * and add them to the game.
     * <p>
     */
    public void initialize() {
        // Create a block remover
        BlockRemover blockRemover = new BlockRemover(this, this.blockCounter);
        // Create a ball remover
        BallRemover ballRemover = new BallRemover(this, this.ballCounter);
        // Create a score listener
        ScoreTrackingListener scoreListener = new ScoreTrackingListener(this.score);
        // Create a new sprites.ScoreIndicator
        ScoreIndicator scoresInd = new ScoreIndicator(this.score);
        scoresInd.addToGame(this);
        // Create a new sprites.LivesIndicator
        LivesIndicator livesInd = new LivesIndicator(this.numberOfLives);
        livesInd.addToGame(this);
        // Create level name
        LevelIndicator levName = new LevelIndicator(this.lev.levelName());
        levName.addToGame(this);
        // Create background
        addSprite(this.lev.getBackground());
        // Create blocks
        for (Block b : lev.blocks()) {
            b.addToGame(this);
            // Add listeners to every block
            b.addHitListener(blockRemover);
            b.addHitListener(scoreListener);
        }
        // Create board boundaries on screen
        boardBoundaries();
        // Functions as a "death region", has -1 num of hits so it will not disappear from the screen
        Block deathRegion = new Block(new Point(0, HEIGHT + BOUNDARY_SIZE),
                WIDTH, BOUNDARY_SIZE, Color.GRAY, -1);
        deathRegion.addClr(-1, Color.GRAY);
        deathRegion.addToGame(this);
        deathRegion.addHitListener(ballRemover);
    }

    /**
     * Run one turn of the game - start the animation loop.
     * <p>
     */
    public void playOneTurn() {
        // Create balls and paddle
        this.createBallsAndPaddle();
        int fps = this.runner.getFps();
        CountdownAnimation countDown = new CountdownAnimation(FRAMES_FOR_COUNT, COUNT_FROM, this.sprites);
        // Count down from 3 and run game
        this.runner.setFramesPerSecond(countDown.getSec()/*COUNT*fps*/);
        // Use our runner to run the current animation -- which is counting down from 3.
        this.runner.run(countDown);
        this.runner.setFramesPerSecond(fps);
        this.running = true;
        // Use our runner to run the current animation -- which is one turn of the game.
        this.runner.run(this);
    }

    /**
     * In charge of stopping condition for the current turn.
     *
     * @return true in order to stop the game, false otherwise.
     */
    public boolean shouldStop() {

        return !this.running;
    }

    /**
     * Puts one frame on surface.
     *
     * @param d  the game surface.
     * @param dt the difference.
     */
    public void doOneFrame(DrawSurface d, double dt) {
        // Show the screen parts
        this.sprites.drawAllOn(d);
        this.sprites.notifyAllTimePassed(dt);
        // When all the balls fall from the screen one life is lost
        if (ballCounter.getValue() == 0) {
            this.numberOfLives.decrease(1);
        }
        // Close game when no more blocks remained
        if (blockCounter.getValue() == 0) {
            // Clearning an entire level (destroying all blocks) is worth another 100 points
            score.increase(100);
            this.running = false;
        }
        // End turn if all balls are dead
        if (ballCounter.getValue() == 0) {
            this.running = false;
        }
        // Pause game
        if (this.keyboard.isPressed("p")) {
            this.runner.run(new KeyPressStoppableAnimation(this.keyboard,
                    KeyboardSensor.SPACE_KEY, new PauseScreen()));
        }
    }

    /**
     * Create 4 blocks as board boundaries.
     * <p>
     */
    public void boardBoundaries() {
        // Create blocks as screen boundaries
        Block upBlock = new Block(new Point(0, BOUNDARY_SIZE - 4), WIDTH, BOUNDARY_SIZE, Color.GRAY, -1);
        upBlock.addClr(-1, Color.GRAY);
        Block leftBlock = new Block(new Point(0, 20), BOUNDARY_SIZE, HEIGHT, Color.GRAY, -1);
        leftBlock.addClr(-1, Color.GRAY);
        Block rightBlock = new Block(new Point(WIDTH - BOUNDARY_SIZE, 20), BOUNDARY_SIZE, HEIGHT,
                Color.GRAY, -1);
        rightBlock.addClr(-1, Color.GRAY);
        // Add to game
        upBlock.addToGame(this);
        leftBlock.addToGame(this);
        rightBlock.addToGame(this);
    }

    /**
     * Remove the given collidable from the sprites.GameEnvironment.
     * <p>
     *
     * @param c collidable object to be removed.
     */
    public void removeCollidable(Collidable c) {
        this.environment.removeCollidable(c);
    }

    /**
     * Remove the given sprite from the sprites list.
     * <p>
     *
     * @param s sprites.Sprite object to be removed.
     */
    public void removeSprite(Sprite s) {
        this.sprites.removeSprite(s);
    }

    /**
     * Create game's balls and paddle.
     */

    public void createBallsAndPaddle() {
        // Create a user-controlled paddle
        int height = 30;
        double x = (gui.getDrawSurface().getWidth() / 2.0) - (this.lev.paddleWidth() / 2.0);
        double y = HEIGHT - BOUNDARY_SIZE - height;
        if (user == null) {
            user = new Paddle(this.keyboard, new Point(x, y), lev.paddleWidth(),
                    height, Color.orange, WIDTH - BOUNDARY_SIZE, this.lev.paddleSpeed());
            user.addToGame(this);
        } else {
            // Locate paddle in the middle
            user.setX(x);
        }
        // Create new balls
        Point loc = new Point(WIDTH / 2, HEIGHT - 100);
        for (int i = 0; i < this.lev.numberOfBalls(); i++) {
            Ball ball = new Ball(loc, RADIUS, Color.white);
            // Associating the ball with the sprites.GameEnvironment
            ball.setGameEvironment(environment);
            // Set screen as ball limits
            ball.setBallLimits(WIDTH - BOUNDARY_SIZE, HEIGHT - BOUNDARY_SIZE, BLOCK_LINE_W);
            // Set ball velocity
            ball.setVelocity(this.lev.initialBallVelocities().get(i));
            ball.addToGame(this);
            this.ballCounter.increase(1);
        }
    }

    /**
     * Getter for lives.
     *
     * @return integer representing the number of lives.
     */
    public int getLives() {
        return this.numberOfLives.getValue();
    }

    /**
     * Getter for the number of blocks in the game.
     *
     * @return integer representing the number of blocks.
     */
    public int getNumBlocks() {
        return this.blockCounter.getValue();
    }
}