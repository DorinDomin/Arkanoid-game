package game;

import animations.Animation;
import animations.AnimationRunner;
import animations.HighScoresAnimation;
import animations.KeyPressStoppableAnimation;
import animations.Menu;
import animations.MenuAnimation;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import levels.LevelInformation;
import task.Task;
import task.GameTask;
import task.SubMenuTask;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import task.QuitTask;
import task.ShowHiScoresTask;
import input.SetsMap;

/**
 * The game.Ass7Game program implements an application that creates a game object,
 * initializes and runs it. The game includes 2 balls,paddle and blocks.
 *
 * @author Dorin Domin
 */
public class Ass7Game {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;

    /**
     * Load table from file.
     *
     * @return HighScoresAnimation.
     */
    public static HighScoresAnimation highSco() {
        // Default size
        HighScoresTable t = null;
        File f = new File("highscores");
        try {
            // File already exists
            if (f.isFile()) {
                t = HighScoresTable.loadFromFile(f);
                if (t.size() > 1) {
                    return new HighScoresAnimation(t);
                }
            } else {
                // Create new file if not exists
                f.createNewFile();
                t = new HighScoresTable();
                t.save(f);
                return new HighScoresAnimation(t);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Loading failed
        t = new HighScoresTable();
        return new HighScoresAnimation(t);
    }

    /**
     * Run menu.
     *
     * @param g     gui.
     * @param r     animation runner.
     * @param k     keyboard sensor.
     * @param path  String.
     * @param table high-score-table.
     */
    private void runMenu(GUI g, AnimationRunner r, KeyboardSensor k, String[] path, HighScoresAnimation table) {
        // Create main menu
        Menu<Task<Void>> menu = new MenuAnimation<Task<Void>>(k);
        menu.addSelection("q", "Quit", new QuitTask(g));
        Animation load = new KeyPressStoppableAnimation(k, KeyboardSensor.SPACE_KEY, table);
        menu.addSelection("h", "High Scores", new ShowHiScoresTask(r, load));
        GameFlow game = new GameFlow(r, k, g);
        SetsMap sM = new SetsMap(path[0]);
        Menu<Task<Void>> levelsMenu = new MenuAnimation<Task<Void>>(k);
        // Load game levels
        if (!sM.create()) {
            System.out.println("Error Loading Files");
            g.close();
        } else {
            ArrayList<ArrayList<LevelInformation>> levelInfoArray = sM.getSets();
            ArrayList<String> keys = sM.getKeys();
            ArrayList<String> desc = sM.getDesc();
            if (levelInfoArray == null || keys == null || desc == null) {
                System.out.println("Error Loading Files");
                g.close();
            } else {
                for (int i = 0; i < keys.size(); i++) {
                    levelsMenu.addSelection(keys.get(i), desc.get(i), new GameTask(game, levelInfoArray.get(i)));
                }
                menu.addSelection("s", "Start Game", new SubMenuTask(r, levelsMenu));
                // Run menu
                while (true) {
                    // Run chosen menu
                    r.run(menu);
                    Task<Void> task = menu.getStatus();
                    task.run();
                    // Show main menu again
                    menu = new MenuAnimation<Task<Void>>(k);
                    menu.addSelection("q", "Quit", new QuitTask(g));
                    load = new KeyPressStoppableAnimation(k, KeyboardSensor.SPACE_KEY, this.highSco());
                    menu.addSelection("h", "High Scores", new ShowHiScoresTask(r, load));
                    game = new GameFlow(r, k, g);
                    levelsMenu = new MenuAnimation<>(k);
                    sM = new SetsMap(path[0]);
                    if (!sM.create()) {
                        System.out.println("Error Loading Files");
                        g.close();
                        return;
                    }
                    levelInfoArray = sM.getSets();
                    keys = sM.getKeys();
                    desc = sM.getDesc();
                    if (levelInfoArray == null || keys == null || desc == null) {
                        System.out.println("Error Loading Files");
                        g.close();
                    } else {
                        for (int i = 0; i < keys.size(); i++) {
                            levelsMenu.addSelection(keys.get(i), desc.get(i),
                                    new GameTask(game, levelInfoArray.get(i)));
                        }
                        menu.addSelection("s", "Start Game", new SubMenuTask(r, levelsMenu));
                    }
                }
            }
        }
    }

    /**
     * Our main method that activates the game.
     * <p>
     *
     * @param args Command line arguments.
     */
    public static void main(String[] args) {
        // Use args
        String[] path = null;
        if (args.length > 1) {
            System.out.println("Invalid passed arguments");
        } else {
            if (args.length != 1) {
                path = new String[]{"level_sets.txt"};
            } else {
                path = args;
            }
            // Load data
            HighScoresAnimation table = highSco();
            final int framesPerSecond = 60;
            GUI gui = new GUI("Arkanoid", WIDTH, HEIGHT);
            AnimationRunner runner = new AnimationRunner(gui, framesPerSecond);
            biuoop.KeyboardSensor k = gui.getKeyboardSensor();
            Ass7Game ass7 = new Ass7Game();
            // Run menu
            ass7.runMenu(gui, runner, k, path, table);
        }
    }
}
