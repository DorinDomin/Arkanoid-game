package game;

import animations.AnimationRunner;
import animations.EndScreen;
import animations.HighScoresAnimation;
import animations.KeyPressStoppableAnimation;
import biuoop.DialogManager;
import biuoop.GUI;
import biuoop.KeyboardSensor;
import levels.LevelInformation;
import sprites.Counter;

import java.io.File;
import java.io.IOException;
import java.util.List;

/**
 * The GameFlow class will be in charge of
 * creating the different levels, and moving from one level to the next.
 *
 * @author Dorin Domin
 */
public class GameFlow {
    public static final String SPACE = KeyboardSensor.SPACE_KEY;
    // Fields
    private AnimationRunner runner;
    private KeyboardSensor sensor;
    private GUI gui;
    private Counter score;
    private Counter lives;
    private HighScoresTable t;

    /**
     * Constructor.
     *
     * @param ar AnimationRunner of the game.
     * @param ks KeyboardSensor of the game.
     * @param g  GUI of the game.
     */
    public GameFlow(AnimationRunner ar, KeyboardSensor ks, GUI g) {
        this.runner = ar;
        this.sensor = ks;
        this.gui = g;
        this.score = new Counter(0);
        this.lives = new Counter(7);
        this.t = new HighScoresTable();
    }

    /**
     * Run levels.
     *
     * @param levels list of level info.
     */
    public void runLevels(List<LevelInformation> levels) {
        // Create new table for game
        File f = new File("highscores");
        try {
            // File already exists
            if (f.isFile()) {
                this.t = HighScoresTable.loadFromFile(f);
                // Table not loaded successfully
                if (!(this.t.size() > 1)) {
                    this.t = new HighScoresTable();
                }
            } else {
                f.createNewFile();
                this.t = new HighScoresTable();
                this.t.save(f);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Run levels
        for (LevelInformation levelInfo : levels) {

            GameLevel level = new GameLevel(levelInfo, this.sensor, this.runner, this.gui, this.score, this.lives);

            level.initialize();
            // Game continues until the player is dead or all blocks are gone
            while (level.getLives() != 0 && level.getNumBlocks() != 0) {
                level.playOneTurn();
            }
            // Case the player lost
            if (this.lives.getValue() == 0) {
                updateTable(f);
                this.runner.run(new KeyPressStoppableAnimation(this.sensor, SPACE,
                        new EndScreen(this.score, false)));
                break;
            }
        }
        // Case the player won
        if (this.lives.getValue() != 0) {
            updateTable(f);
            this.runner.run(new KeyPressStoppableAnimation(this.sensor, SPACE,
                    new EndScreen(this.score, true)));
           /* //*************************************************
            HighScoresTable t = new HighScoresTable(4);
            t.add(new ScoreInfo("Orchen", 300));
            t.add(new ScoreInfo("Agam", 300));
            t.add(new ScoreInfo("Aria", 50));
            t.add(new ScoreInfo("Dorian", 99));
            t.add(new ScoreInfo("Bashir", 15));
            t.add(new ScoreInfo("Inanna", 0));
            t.add(new ScoreInfo("Alian", 48));
            this.runner.run(new KeyPressStoppableAnimation(this.sensor, SPACE,
                    new HighScoresAnimation(t)));
            //**************************************************/

        }
        this.runner.run(new KeyPressStoppableAnimation(this.sensor, SPACE,
                new HighScoresAnimation(this.t)));
    }

    /**
     * Update table.
     *
     * @param f file to save.
     */
    public void updateTable(File f) {
        // Check if player needs to be in table
        if (this.t.getRank(this.score.getValue()) <= this.t.size()) {
            // Show dialog manager
            DialogManager dialog = gui.getDialogManager();
            String name = dialog.showQuestionDialog("Name", "What is your name?", "Anonymous");
            this.t.add(new ScoreInfo(name, this.score.getValue()));
        }
        try {
            // Save updates
            this.t.save(f);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
