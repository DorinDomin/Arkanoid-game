package game;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * The HighScoresTable class used to manege the highest scores in the game.
 *
 * @author Dorin Domin
 */
public class HighScoresTable implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final int SIZE = 5;
    private int max;
    private List<ScoreInfo> scores;
    private final transient Comparator<ScoreInfo> comp = new Comparator<ScoreInfo>() {
        public int compare(ScoreInfo player1, ScoreInfo player2) {
            if (player1.getScore() > player2.getScore()) {
                return 1;
            }
            if (player1.getScore() < player2.getScore()) {
                return -1;
            }
            return 0;
        }
    };

    /**
     * Constructor.
     *
     * @param size integer representing the num of highest scores to be saved.
     */
    public HighScoresTable(int size) {
        this.max = size;
        this.scores = new ArrayList<ScoreInfo>(size);
    }

    /**
     * Constructor.
     * Create an empty high-scores table with the specified size.
     */
    public HighScoresTable() {
        this.max = SIZE;
        this.scores = new ArrayList<ScoreInfo>(SIZE);
    }

    /**
     * Add a high-score.
     *
     * @param score ScoreInfo to add.
     */
    public void add(ScoreInfo score) {
        int rank = getRank(score.getScore());
        if (rank <= this.max) {
            this.scores.add(rank - 1, score);
            if (this.scores.size() > this.max) {
                this.scores.remove(this.scores.size() - 1);
            }
        }
    }

    /**
     * Return table size.
     *
     * @return table size.
     */
    public int size() {
        return this.max;
    }

    /**
     * Return the current high scores.
     * The list is sorted such that the highest
     * scores come first.
     *
     * @return current high scores.
     */
    public List<ScoreInfo> getHighScores() {
        if (this.scores != null) {
            Collections.sort(this.scores, Collections.reverseOrder(comp));
        }
        return this.scores;
    }

    /**
     * Return the rank of the current score.
     *
     * @param score integer.
     * @return integer representing the rank.
     */
    public int getRank(int score) {
        // Create a copy,insert score and check location
        ArrayList<ScoreInfo> copy = new ArrayList<ScoreInfo>(this.max + 1);
        copy.addAll(this.scores);
        // ScoreInfo Comparator
        copy.add(new ScoreInfo("", score));
        Collections.sort(copy, Collections.reverseOrder(comp));
        int rank = 0;
        // Iterate and return the location of the new score
        for (int i = 0; i < copy.size(); i++) {
            if (copy.get(i).getScore() == score) {
                rank = i + 1;
                break;
            }
        }
        return rank;
    }

    /**
     * Clears the table.
     */
    public void clear() {
        this.scores.clear();
    }

    /**
     * Load table data from file.
     * Current table data is cleared.
     *
     * @param filename to load data from.
     * @throws IOException exception.
     */
    public void load(File filename) throws IOException {
        FileInputStream input = null;
        ObjectInputStream obj = null;
        try {
            // Try loading from file
            input = new FileInputStream(filename);
            obj = new ObjectInputStream(input);
            HighScoresTable tab = (HighScoresTable) obj.readObject();
            // Save data from file
            this.max = tab.size();
            this.scores = tab.getHighScores();
        } catch (IOException e) {
            throw e;
        } catch (ClassNotFoundException c) {
            c.printStackTrace();
        } finally {
            // Close streams
            if (obj != null) {
                try {
                    obj.close();
                } catch (IOException e) {
                    throw e;
                }
            }
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    throw e;
                }
            }
        }
    }

    /**
     * Save table data to the specified file.
     *
     * @param filename location for saving data.
     * @throws IOException exception.
     */
    public void save(File filename) throws IOException {
        FileOutputStream output = null;
        ObjectOutputStream obj = null;
        try {
            // Try writing data to file
            output = new FileOutputStream(filename);
            obj = new ObjectOutputStream(output);
            obj.writeObject(this);
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            // Close streams
            if (obj != null) {
                try {
                    obj.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (output != null) {
                try {
                    output.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * Read a table from file and return it.
     *
     * @param filename to load data from.
     * @return table.
     */
    public static HighScoresTable loadFromFile(File filename) {
        try {
            // Try loading data from file
            HighScoresTable tab = new HighScoresTable(1);
            tab.load(filename);
            return tab;
        } catch (IOException e) {
            // If process failed - return an empty table
            return new HighScoresTable(1);
        }
    }
}
