package game;

import java.io.Serializable;

/**
 * Implementation for scoreInfo.
 *
 * @author Dorin Domin
 */
public class ScoreInfo implements Serializable, Comparable<ScoreInfo> {
    //Fields
    private String player;
    private int scores;
    private static final long serialVersionUID = 1L;

    /**
     * Constructor.
     *
     * @param name  String.
     * @param score integer.
     */
    public ScoreInfo(String name, int score) {
        this.player = name;
        this.scores = score;
    }

    /**
     * Getter for name.
     *
     * @return String.
     */
    public String getName() {
        return this.player;
    }

    /**
     * Getter for score.
     *
     * @return integer.
     */
    public int getScore() {
        return this.scores;
    }

    /**
     * Comparator.
     *
     * @param scr ScoreInfo.
     * @return integer.
     */
    public int compareTo(ScoreInfo scr) {
        if (this.getScore() > scr.getScore()) {
            return 1;
        }
        if (this.getScore() < scr.getScore()) {
            return -1;
        }
        return 0;
    }
}
