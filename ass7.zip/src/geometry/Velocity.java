package geometry;

/**
 * The geometry.Velocity program implements an application that specifies
 * the change in position on the `x` and the `y` axes.
 *
 * @author Dorin Domin
 */
public class Velocity {
    public static final double DEFAULT_DX = 1;
    public static final double DEFAULT_DY = 1;

    // Fields
    private double dx;
    private double dy;

    /**
     * Constructor.
     * <p>
     *
     * @param dx the change in X axis.
     * @param dy the change in Y axis.
     */
    public Velocity(double dx, double dy) {
        this.dx = dx;
        this.dy = dy;
    }

    /**
     * Constructor.
     * Sets default values for dx and dy.
     * <p>
     */
    public Velocity() {
        this.dx = DEFAULT_DX;
        this.dy = DEFAULT_DY;
    }

    /**
     * Constructor to geometry.Velocity, taking an angle an a speed.
     * <p>
     *
     * @param angle the direction.
     * @param speed Size of progress.
     * @return new velocity.
     */
    public static Velocity fromAngleAndSpeed(double angle, double speed) {
        double dy = speed * (Math.sin(Math.toRadians(angle * (-1))));
        double dx = speed * (Math.cos(Math.toRadians(angle)));
        return new Velocity(dx, dy);
    }

    /**
     * Allows access to the x value of the velocity of ball.
     * <p>
     *
     * @return x value of velocity.
     */
    public double getXVelocity() {
        return this.dx;
    }

    /**
     * Allows access to the y value of the velocity of ball.
     * <p>
     *
     * @return y value of velocity.
     */
    public double getYVelocity() {
        return this.dy;
    }

    /**
     * Take a point with position (x,y) and return a new point,
     * with position (x+dx, y+dy).
     * <p>
     *
     * @param p  start position.
     * @param dt difference.
     * @return new position (point).
     */
    public Point applyToPoint(Point p, double dt) {

        return new Point(p.getX() + (dx * dt), p.getY() + (dy * dt));
    }

    /**
     * Change dy direction.
     * <p>
     *
     * @return new velocity with an updated dy direction.
     */
    public Velocity changeDyVel() {
        return new Velocity(this.dx, -this.dy);
    }

    /**
     * Change dX direction.
     * <p>
     *
     * @return new velocity with an updated dX direction.
     */
    public Velocity changeDxVel() {
        return new Velocity(-this.dx, this.dy);
    }

    /**
     * Check if dx changes.
     * <p>
     *
     * @param newDx new dx to be compared.
     * @return true if dx changed, false otherwise.
     */
    public Boolean ifChangedDx(double newDx) {
        return this.getXVelocity() * newDx < 0;
    }

    /**
     * Check if dy changes.
     * <p>
     *
     * @param newDy new dy to be compared.
     * @return true if dy changed, false otherwise.
     */
    public Boolean ifChangedDy(double newDy) {
        return this.getYVelocity() * newDy < 0;
    }

    /**
     * Get speed out of current velocity.
     * <p>
     *
     * @return current speed.
     */
    public double getSpeed() {
        // Use pythagoras
        double dxPow = Math.pow(getXVelocity(), 2);
        double dyPow = Math.pow(getYVelocity(), 2);

        return Math.sqrt(dxPow + dyPow);
    }
}