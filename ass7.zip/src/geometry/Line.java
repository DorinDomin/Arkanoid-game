package geometry;

import java.util.List;
import java.util.Iterator;


/**
 * The geometry.Line program implements an application for a geometry.Line abject.
 * Lines have lengths, and may intersect with other lines.
 * It can also tell if it is the same as another line segment.
 *
 * @author Dorin Domin
 */
public class Line {
    public static final double EPSILON = 0.0000000000001;

    // Fields
    private Point pStart;
    private Point pEnd;

    /**
     * Constructor.
     * <p>
     *
     * @param start the beginning of a line.
     * @param end   the end of a line.
     */
    public Line(Point start, Point end) {
        this.pStart = new Point(start.getX(), start.getY());
        this.pEnd = new Point(end.getX(), end.getY());
    }

    /**
     * Constructor.
     * <p>
     *
     * @param x1 the x value of the beginning of a line.
     * @param y1 the y value of the beginning of a line.
     * @param x2 the x value of the beginning of a line.
     * @param y2 the y value of the beginning of a line.
     */
    public Line(double x1, double y1, double x2, double y2) {
        this.pStart = new Point(x1, y1);
        this.pEnd = new Point(x2, y2);
    }

    /**
     * Allows access to the start point of a line.
     * <p>
     *
     * @return line's starting point.
     */
    public Point start() {
        return this.pStart;
    }

    /**
     * Allows access to the end point of a line.
     * <p>
     *
     * @return line's ending point.
     */
    // Returns the end point of the line
    public Point end() {
        return this.pEnd;
    }

    /**
     * Calculate line length.
     * <p>
     *
     * @return line length,type double.
     */
    public double length() {
        return this.pStart.distance(this.pEnd);
    }

    /**
     * Calculate middle point of the line.
     * <p>
     *
     * @return the middle point of a line.
     */
    public Point middle() {
        Point midPoint;
        // Find middle point's x value
        double midX = (pStart.getX() + pEnd.getX()) / 2;
        // Find middle point's y value
        double midY = (pStart.getY() + pEnd.getY()) / 2;
        // Return the middle point
        midPoint = new Point(midX, midY);
        return midPoint;
    }

    /**
     * Calculate incline of the line.
     * <p>
     *
     * @return the middle point of a line,type double.
     */
    public double incline() {
        double dy = this.pEnd.getY() - this.pStart.getY();
        double dx = this.pEnd.getX() - this.pStart.getX();

        // If line is a point,can't divide by zero
        if (dx == 0) {
            return 0.0;
        }
        return dy / dx;
    }

    /**
     * Check if two lines intersecting.
     * <p>
     *
     * @param other line to check intersecting with.
     * @return true if the lines intersect, false otherwise.
     */
    public boolean isIntersecting(Line other) {
        return (intersectionWith(other) != null);
    }

    /**
     * Implementation of a straight line equation.
     * <p>
     *
     * @param xValue an x double value to place in straight line equation.
     * @return Y value at point x.
     */
    public double equation(double xValue) {
        double incline = this.incline();
        return ((incline * (xValue - this.pStart.getX()) + this.pStart.getY()));
    }

    /**
     * Check if line is parallel to the y axis.
     * <p>
     *
     * @return true if the line is vertical,false otherwise.
     */
    public Boolean isVertical() {
        return ((this.pStart.getX() == this.pEnd.getX())
                && (this.pStart.getY() != this.pEnd.getY()));
    }

    /**
     * Check intersecting between two vertical lines.
     * <p>
     *
     * @param other line to check with.
     * @return intersecting point if exists.
     */
    public Point verticalIntersection(Line other) {
        // Same line
        if (this.equals(other)) {
            return this.pStart;
        } else if (this.pStart.getX() == other.pStart.getX()) {
            // Check the edges
            if (other.pStart.equals(this.pStart)) {
                return this.pEnd;
            }
            if (other.pEnd.equals(this.pEnd)) {
                return this.pStart;
            }
            if (other.pStart.getY() >= this.pStart.getY()
                    && other.pStart.getY() <= this.pEnd.getY()) {
                return other.pStart;
            }
            if (other.pEnd.getY() >= this.pStart.getY()
                    && other.pEnd.getY() <= this.pEnd.getY()) {
                return other.pEnd;
            }
        }
        return null;
    }

    /**
     * Find intersecting point between two lines,
     * where one line is parallel to the y axis.
     * <p>
     *
     * @param other line to check with.
     * @return intersecting point if exists.
     */
    public Point onVerticalLine(Line other) {
        // Find inter-point if other is a line
        if (!other.lineIsPoint()) {
            double interX = this.pStart.getX();
            double interY = other.equation(interX);
            Point inter = new Point(interX, interY);
            // If intersection point on vertical line
            if (this.checkOnLine(inter) && other.checkOnLine(inter)) {
                return (inter);
            }
        } else if (checkOnLine(other.pStart)) {
            // Inter-point is the other line
            return other.pStart;
        }
        return null;
    }

    /**
     * Check if point is on line.
     * <p>
     *
     * @param inter a point to check.
     * @return true if inter on line,false otherwise.
     */
    public boolean checkOnLine(Point inter) {
        // Calculate the distance of inter from line
        double dis = inter.distance(this.pStart) + inter.distance(this.pEnd);
        // Use triangle inequality to determine whether inter is on line
        return (dis - this.length()) < EPSILON;
    }

    /**
     * Calculate intersecting point between two lines.
     * <p>
     *
     * @param other a line to calculate intersecting with.
     * @return intersecting point.
     */
    public Point calculateIntersectionsP(Line other) {
        double thisIncline = this.incline();
        double otherIncline = other.incline();
        double interX, interY;
        double thisScalar, otherScalar;

        // Lines are parallel,can't perform a zero division
        if (thisIncline == otherIncline) {
            return this.overlapping(other);
        }
        // Find x by straight line equation
        thisScalar = thisIncline * (-this.pStart.getX()) + this.pStart.getY();
        otherScalar = otherIncline * (-other.pStart.getX()) + other.pStart.getY();
        interX = (otherScalar - thisScalar) / (thisIncline - otherIncline);
        // Find y by straight line equation
        interY = this.equation(interX);

        return new Point(interX, interY);
    }

    /**
     * Find intersecting point between two lines.
     * <p>
     *
     * @param other a line to check intersecting with.
     * @return the intersection point if the lines intersect,
     * and null otherwise.
     */
    public Point intersectionWith(Line other) {
        Point interP;
        // Both lines are vertical
        if (this.isVertical() && other.isVertical()) {
            return verticalIntersection(other);
        }
        // One line is vertical
        if (this.isVertical()) {
            return onVerticalLine(other);
        }
        if (other.isVertical()) {
            return other.onVerticalLine(this);
        }
        // Finding inter-point and checking if on lines
        interP = calculateIntersectionsP(other);
        // Check if point is on the lines
        if (interP != null && (other.checkOnLine(interP)
                && this.checkOnLine(interP))) {
            return interP;
        }
        return null;
    }

    /**
     * Check if two lines are equals.
     * <p>
     *
     * @param other a line to check with.
     * @return true is the lines are equal, false otherwise.
     */
    public boolean equals(Line other) {
        return (this.pStart.equals(other.pStart)
                && this.pEnd.equals(other.pEnd));
    }

    /**
     * Check if lines overlapping.
     * <p>
     *
     * @param other a line to check with.
     * @return true if lines overlapping, false otherwise.
     */
    public Point overlapping(Line other) {
        // Check if lines overlapping
        if (this.length() <= other.length()) {
            return this.pStart;
        }
        return other.pStart;
    }

    /**
     * Check if line is a point.
     * <p>
     *
     * @return true if line is a point, false otherwise.
     */
    public boolean lineIsPoint() {
        return this.pStart.equals(this.pEnd);
    }

    /**
     * Find closest intersection point to the start of the line.
     * <p>
     *
     * @param rect a rectangle to check with.
     * @return the closest intersection point to the start of the line or null.
     */
    public Point closestIntersectionToStartOfLine(Rectangle rect) {
        Point min;
        // Get a list of intersection points
        List<Point> interList = rect.intersectionPoints(this);
        // geometry.Line does not intersect with the rectangle
        if (interList.isEmpty()) {
            return null;
        }
        // Find closest intersection point to the start of line
        Iterator<Point> iterator = interList.iterator();
        min = iterator.next();
        while (iterator.hasNext()) {
            min = this.pStart.closestPoint(min, iterator.next());
        }
        return min;
    }
}
