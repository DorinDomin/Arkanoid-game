package geometry;

/**
 * The geometry.Point program implements an application for a point abject.
 * A point has an x and a y value, and can measure the distance to other points,
 * and if its is equal to another point.
 *
 * @author Dorin Domin
 */
public class Point {

    // Fields
    private double x;
    private double y;

    /**
     * Constructor.
     * <p>
     *
     * @param x double x value of point.
     * @param y a double y value of point.
     */
    public Point(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Allows access to the x value of a point.
     * <p>
     *
     * @return x value type double.
     */
    public double getX() {
        return this.x;
    }

    /**
     * Allows access to the y value of a point.
     * <p>
     *
     * @return y value type double.
     */
    public double getY() {
        return this.y;
    }

    /**
     * Assignment to X value of a point.
     * <p>
     *
     * @param newX double value for x field.
     */
    public void setX(double newX) {
        this.x = newX;
    }

    /**
     * Assignment to Y value of a point.
     * <p>
     *
     * @param newY double value for Y field.
     */
    public void setY(double newY) {
        this.y = newY;
    }

    /**
     * Return the distance of this point to the other point.
     * <p>
     *
     * @param other a point to measure the distance to it.
     * @return the distance type double.
     */
    public double distance(Point other) {
        // Check for null values
        if (other == null) {
            return 0.0;
        }
        double dx = this.x - other.x;
        double dy = this.y - other.y;
        // Use a mathematical formula for a distance between two points
        return Math.sqrt(dx * dx + dy * dy);
    }

    /**
     * Compare two points.
     * <p>
     *
     * @param other a point to compare.
     * @return true if the points are equal, false otherwise.
     */
    public boolean equals(Point other) {
        // Check for null values
        if (other == null) {
            return false;
        }
        return (this.x == other.x && this.y == other.y);
    }

    /**
     * Return the closest point between two points.
     *
     * @param first  point.
     * @param second point.
     * @return point.
     */
    public Point closestPoint(Point first, Point second) {
        // Check null values
        if (second == null && first == null) {
            return null;
        }
        if (first != null && second == null) {
            return first;
        }
        if (second != null && first == null) {
            return second;
        }
        // Return the closet by distance
        if (first.distance(this) <= second.distance(this)) {
            return first;
        }
        return second;
    }
}
