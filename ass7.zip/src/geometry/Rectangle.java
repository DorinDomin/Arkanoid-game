package geometry;

import java.util.List;
import java.util.ArrayList;

/**
 * The geometry.Rectangle program implements an application for a rectangle object.
 * Rectangles has an upper left point, width and height.
 *
 * @author Dorin Domin
 */
public class Rectangle {

    // Fields
    private Point upperLeftP;
    private int width;
    private int height;

    /**
     * Constructor.
     * Create a new rectangle with location and width/height.
     * <p>
     *
     * @param upperLeft upper point of the new rectangle.
     * @param width     the width of the new rectangle.
     * @param height    the height of the new rectangle.
     */
    public Rectangle(Point upperLeft, int width, int height) {
        this.upperLeftP = new Point(upperLeft.getX(), upperLeft.getY());
        this.width = width;
        this.height = height;
    }

    /**
     * Return a (possibly empty) List of intersection points with the specified line.
     *
     * @param line to find intersections points with.
     * @return a list of intersection points with line.
     */
    public java.util.List<Point> intersectionPoints(Line line) {
        // Creates a new list of points
        List<Point> interList = new ArrayList<Point>();
        // Check intersection with every slope of the current rectangle
        if (getLeftVerticleLine().isIntersecting(line)) {
            interList.add(getLeftVerticleLine().intersectionWith(line));
        }
        if (getRightVerticleLine().isIntersecting(line)) {
            interList.add(getRightVerticleLine().intersectionWith(line));
        }
        if (getUpperParallelLine().isIntersecting(line)) {
            interList.add(getUpperParallelLine().intersectionWith(line));
        }
        if (getDownParallelLine().isIntersecting(line)) {
            interList.add(getDownParallelLine().intersectionWith(line));
        }
        return interList;
    }

    /**
     * Return the width of the rectangle.
     * <p>
     *
     * @return current rectangle's width.
     */
    public int getWidth() {
        return this.width;
    }

    /**
     * Return the height of the rectangle.
     * <p>
     *
     * @return current rectangle's height.
     */
    public int getHeight() {
        return this.height;
    }

    /**
     * Returns the upper-left point of the rectangle.
     * <p>
     *
     * @return current rectangle's upper-left-point.
     */
    public Point getUpperLeftP() {
        return this.upperLeftP;
    }

    /**
     * Returns the upper-right point of the rectangle.
     * <p>
     *
     * @return current rectangle's upper-right-point.
     */
    public Point getUpperRightP() {
        return new Point(upperLeftP.getX() + width, upperLeftP.getY());
    }

    /**
     * Returns the down-left point of the rectangle.
     * <p>
     *
     * @return current rectangle's down-left-point.
     */
    public Point getDownLeftP() {
        return new Point(upperLeftP.getX(), upperLeftP.getY() + height);
    }

    /**
     * Returns the down-right point of the rectangle.
     * <p>
     *
     * @return current rectangle's down-right-point.
     */
    public Point getDownRightP() {
        return new Point(upperLeftP.getX() + width, upperLeftP.getY() + height);
    }

    /**
     * Create and Return the left-verticle line of the rectangle.
     * <p>
     *
     * @return a new line, left verticle line of the current triangle.
     */
    public Line getLeftVerticleLine() {
        return new Line(upperLeftP, getDownLeftP());
    }

    /**
     * Create and Return the right-verticle line of the rectangle.
     * <p>
     *
     * @return a new line, right verticle line of the current triangle.
     */
    public Line getRightVerticleLine() {
        return new Line(getUpperRightP(), getDownRightP());
    }

    /**
     * Create and Return the upper paralle line of the rectangle.
     * <p>
     *
     * @return a new line, upper paralle line of the current triangle.
     */
    public Line getUpperParallelLine() {
        return new Line(upperLeftP, getUpperRightP());
    }

    /**
     * Create and Return the down paralle line of the rectangle.
     * <p>
     *
     * @return a new line, down paralle line of the current triangle.
     */
    public Line getDownParallelLine() {
        return new Line(getDownLeftP(), getDownRightP());
    }

    /**
     * Set the upper-left-point of the rectangle.
     * <p>
     * @param newP a point.
     */
    public void setUpperLeftP(Point newP) {
        this.upperLeftP = newP;
    }

    /**
     * Return the location of the current triangle.
     * <p>
     *
     * @return upper left point of the triangle.
     */
    public Point getLocation() {
        return upperLeftP;
    }

    /**
     * Return the size of the current triangle.
     * <p>
     *
     * @return current triangle's size.
     */
    public int getSize() {
        return height * width;
    }

    /**
     * Find and return the closest vertex of the current triangle to target.
     * Closest vertex should be in radius distance from target.
     * <p>
     *
     * @param target to find the closest vertex to.
     * @param radius the distance between the closest vertex to target.
     * @return closest vertex.
     */
    public Point closestVertex(Point target, int radius) {
        // Check upper vertices
        Point checkUp = target.closestPoint(getUpperLeftP(), getUpperRightP());
        // Check down vertices
        Point checkDown = target.closestPoint(getDownLeftP(), getDownRightP());
        // Return closest rectangle's vertex to target
        Point min = target.closestPoint(checkUp, checkDown);

        if (min.distance(target) < radius) {
            return min;
        }
        return null;
    }
}