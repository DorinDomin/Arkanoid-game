package task;

import animations.Animation;
import animations.AnimationRunner;

/**
 * The ShowHiScoresTask class is in charge of the game's show score task.
 *
 * @author Dorin Domin
 */
public class ShowHiScoresTask implements Task<Void> {
    // Fields
    private AnimationRunner runner;
    private Animation highScoresAnimation;

    /**
     * Constructor.
     *
     * @param runner              animation runner.
     * @param highScoresAnimation animation.
     */
    public ShowHiScoresTask(AnimationRunner runner, Animation highScoresAnimation) {
        this.runner = runner;
        this.highScoresAnimation = highScoresAnimation;
    }

    /**
     * Run task.
     *
     * @return Void.
     */
    public Void run() {
        this.runner.run(this.highScoresAnimation);
        return null;
    }
}
