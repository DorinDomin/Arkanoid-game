package task;

import animations.AnimationRunner;
import animations.Menu;

/**
 * Implementation of sub-menu.
 *
 * @author Dorin Domin
 */
public class SubMenuTask implements Task<Void> {
    // Fields
    private AnimationRunner runner;
    private Menu<Task<Void>> subMenu;

    /**
     * Constructor.
     *
     * @param runner animation runner.
     * @param sub    Menu-task-void.
     */
    public SubMenuTask(AnimationRunner runner, Menu<Task<Void>> sub) {
        this.runner = runner;
        this.subMenu = sub;
    }

    /**
     * Run task.
     *
     * @return Void.
     */
    public Void run() {
        this.runner.run(this.subMenu);
        Task<Void> task = this.subMenu.getStatus();
        task.run();
        return null;
    }
}
