package task;

import game.GameFlow;
import levels.LevelInformation;

import java.util.ArrayList;

/**
 * The GameTask class is in charge of the game's tasks.
 *
 * @author Dorin Domin
 */
public class GameTask implements Task<Void> {
    // Fields
    private final GameFlow g;
    private final ArrayList<LevelInformation> lev;

    /**
     * Constructor.
     *
     * @param flow game flow.
     * @param p    list of level-info.
     */
    public GameTask(GameFlow flow, ArrayList<LevelInformation> p) {
        this.g = flow;
        this.lev = p;
    }

    /**
     * Run task.
     *
     * @return Void.
     */
    public Void run() {
        this.g.runLevels(this.lev);
        return null;
    }
}
