package task;

/**
 * Implementation of task interface.
 *
 * @param <T> generics.
 * @author Dorin Domin
 */

public interface Task<T> {
    /**
     * Run task.
     *
     * @return Void.
     */
    T run();
}
