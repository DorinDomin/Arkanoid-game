package task;

import biuoop.GUI;

/**
 * The QuitTask class is in charge of the quit game task.
 *
 * @author Dorin Domin
 */
public class QuitTask implements Task<Void> {
    // Fields
    private final GUI gui;

    /**
     * Constructor.
     *
     * @param g gui.
     */
    public QuitTask(GUI g) {
        this.gui = g;
    }

    /**
     * Run task.
     *
     * @return Void.
     */
    public Void run() {
        this.gui.close();
        return null;
    }
}
