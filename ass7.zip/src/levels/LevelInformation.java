package levels;

import geometry.Velocity;
import sprites.Sprite;
import sprites.Block;

import java.util.List;

/**
 * The LevelInformation interface specifies the information required to fully describe a level.
 *
 * @author Dorin Domin
 */
public interface LevelInformation {
    /**
     * Returns the number of Balls.
     *
     * @return integer representing the number of balls.
     */
    int numberOfBalls();

    /**
     * The initial velocity of each ball.
     *
     * @return list of velocities.
     */
    List<Velocity> initialBallVelocities();

    /**
     * Return paddle's speed in current level.
     *
     * @return integer representing paddle's speed.
     */
    int paddleSpeed();

    /**
     * Return paddle's size in current level.
     *
     * @return integer representing paddle's size.
     */
    int paddleWidth();

    /**
     * Return current level's name.
     *
     * @return string representing level's name.
     */
    String levelName();

    /**
     * Returns a sprite with the background of the level.
     *
     * @return sprite representing level's background.
     */
    Sprite getBackground();

    /**
     * The initial of the blocks of the current level.
     *
     * @return list of blocks.
     */
    List<Block> blocks();

    /**
     * Return the number of blocks in the current level.
     *
     * @return integer representing the number of blocks.
     */
    int numberOfBlocksToRemove();

    /**
     * The initial of balls locations.
     *
     * @return list of points.
     */
/*
    List<Point> ballLocations();
*/
}
