package levels;

import geometry.Point;
import geometry.Velocity;
import sprites.Background2;
import sprites.Block;
import sprites.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * The WideEasy class is a level in the game.
 *
 * @author Dorin Domin
 */
public class WideEasy implements LevelInformation {
    public static final int ANGLE = 0;
    public static final int WIDTH = 800;
    public static final int HIEGHT = 600;
    public static final Point BLOCKS_START = new Point(721, 278);
    public static final Point LOC = new Point(WIDTH / 2, HIEGHT - 100);
    // Fields
    private int numOfBalls = 10;
    private final int numBlocks = 15;
    private int speed = 8;
    private int paddleSpeed = 4;
    private int paddleWidth = 500;
    private String levelName = "Wide Easy";
    private int blockWdth = 50;
    private int blockHeight = 30;

    /**
     * Returns the number of Balls.
     *
     * @return integer representing the number of balls.
     */
    public int numberOfBalls() {
        return this.numOfBalls;
    }

    /**
     * The initial velocity of each ball.
     *
     * @return list of velocities.
     */
    public List<Velocity> initialBallVelocities() {
        ArrayList<Velocity> listOfVel = new ArrayList<Velocity>();
        // Divide balls into different directions
        for (int i = numOfBalls / 2; i > 0; i--) {
            listOfVel.add(Velocity.fromAngleAndSpeed(ANGLE + 15 * i, (double) speed));
        }
        for (int i = numOfBalls / 2; i > 0; i--) {
            listOfVel.add(Velocity.fromAngleAndSpeed(ANGLE - 15 * i, (double) speed));
        }
        return listOfVel;
    }

    /**
     * The initial of balls locations.
     *
     * @return list of points.
     */
   /* public List<Point> ballLocations() {
        ArrayList<Point> listOfLoc = new ArrayList<Point>();
        for (int i = 0; i < this.numOfBalls; i++) {
            listOfLoc.add(LOC);
        }
        return listOfLoc;
    }*/

    /**
     * Return paddle's speed in current level.
     *
     * @return integer representing paddle's speed.
     */
    public int paddleSpeed() {
        return this.paddleSpeed;
    }

    /**
     * Return paddle's size in current level.
     *
     * @return integer representing paddle's size.
     */
    public int paddleWidth() {
        return this.paddleWidth;
    }

    /**
     * Return current level's name.
     *
     * @return string representing level's name.
     */
    public String levelName() {
        return this.levelName;
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return sprite representing level's background.
     */
    public Sprite getBackground() {
        return new Background2();
    }

    /**
     * The initial of the blocks of the current level.
     *
     * @return list of blocks.
     */
    public List<Block> blocks() {
        ArrayList<Block> blocksList = new ArrayList<Block>();
        // Set blocks colors
        Color[] color = {Color.cyan, Color.pink, Color.blue, Color.green, Color.yellow, Color.orange, Color.red};
        int i = 0;
        for (; i < 6; i++) {
            Point upperLeft = new Point(BLOCKS_START.getX() - this.blockWdth * i,
                    BLOCKS_START.getY());
            Block block = new Block(upperLeft, this.blockWdth, this.blockHeight,
                    color[(i / 2) % (color.length)],
                    1);
            blocksList.add(block);
        }
        for (; i < 9; i++) {
            Point upperLeft = new Point(BLOCKS_START.getX() - this.blockWdth * i,
                    BLOCKS_START.getY());
            Block block = new Block(upperLeft, this.blockWdth, this.blockHeight,
                    color[3],
                    1);
            blocksList.add(block);
        }
        for (; i < this.numBlocks; i++) {
            Point upperLeft = new Point(BLOCKS_START.getX() - this.blockWdth * i,
                    BLOCKS_START.getY());
            Block block = new Block(upperLeft, this.blockWdth, this.blockHeight,
                    color[((i - 1) / 2) % (color.length)],
                    1);
            blocksList.add(block);
        }
        return blocksList;
    }

    /**
     * Return the number of blocks in the current level.
     *
     * @return integer representing the number of blocks.
     */
    public int numberOfBlocksToRemove() {
        return this.numBlocks;
    }
}
