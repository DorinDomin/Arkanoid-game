package levels;

import geometry.Point;
import geometry.Velocity;
import sprites.Background1;
import sprites.Block;
import sprites.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * The DirectHit class is a level in the game.
 *
 * @author Dorin Domin
 */
public class DirectHit implements LevelInformation {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    // Fields
    private int numOfBalls = 1;
    private int speed = 10;
    private int paddleWidth = 100;
    private String levelName = "Direct Hit";
    private int blockSize = 40;
    private Velocity ballVelocity = Velocity.fromAngleAndSpeed(0, (double) speed);
    private Point loc = new Point(WIDTH / 2, HEIGHT - 100);

    /**
     * Returns the number of Balls.
     *
     * @return integer representing the number of balls.
     */
    public int numberOfBalls() {
        return this.numOfBalls;
    }

    /**
     * The initial velocity of each ball.
     *
     * @return list of velocities.
     */
    public List<Velocity> initialBallVelocities() {
        ArrayList<Velocity> listOfVel = new ArrayList<Velocity>();
        listOfVel.add(this.ballVelocity);
        return listOfVel;
    }

    /**
     * Return paddle's speed in current level.
     *
     * @return integer representing paddle's speed.
     */
    public int paddleSpeed() {
        return this.speed;
    }

    /**
     * Return paddle's size in current level.
     *
     * @return integer representing paddle's size.
     */
    public int paddleWidth() {
        return this.paddleWidth;
    }

    /**
     * Return current level's name.
     *
     * @return string representing level's name.
     */
    public String levelName() {
        return this.levelName;
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return sprite representing level's background.
     */
    public Sprite getBackground() {
        return new Background1();
    }

    /**
     * The initial of the blocks of the current level.
     *
     * @return list of blocks.
     */
    public List<Block> blocks() {
        ArrayList<Block> blocksList = new ArrayList<Block>();
        Block b = new Block(new Point(380, 180), blockSize, blockSize, Color.RED, 1);
        blocksList.add(b);
        return blocksList;
    }

    /**
     * Return the number of blocks in the current level.
     *
     * @return integer representing the number of blocks.
     */
    public int numberOfBlocksToRemove() {
        return this.blocks().size();
    }

    /**
     * The initial of balls locations.
     *
     * @return list of points.
     */
    /*public List<Point> ballLocations() {
        ArrayList<Point> ballsLoc = new ArrayList<Point>();
        for (int i = 0; i < this.numOfBalls; i++) {
            ballsLoc.add(loc);
        }
        return ballsLoc;
    }*/
}
