package levels;

import geometry.Point;
import geometry.Velocity;
import sprites.Background4;
import sprites.Block;
import sprites.Sprite;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

/**
 * The FinalFour class is a level in the game.
 *
 * @author Dorin Domin
 */
public class FinalFour implements LevelInformation {
    public static final int ANGLE = 0;
    public static final int WIDTH = 800;
    public static final int HIEGHT = 600;
    public static final int BOUNDARY_SIZE = 30;
    public static final int NUM_OF_LINES = 7;
    public static final int BLOCK_IN_LINE = 15;
    public static final int BLOCK_LINE_W = 50;
    public static final int BLOCK_LINE_H = 25;
    public static final Point LOC = new Point(WIDTH / 2, HIEGHT - 100);
    // Fields
    private int numOfBalls = 3;
    private final int numBlocks = 105;
    private int speed = 12;
    private int paddleSpeed = 18;
    private int paddleWidth = 110;
    private String levelName = "Final Four";

    /**
     * Returns the number of Balls.
     *
     * @return integer representing the number of balls.
     */
    public int numberOfBalls() {
        return this.numOfBalls;
    }

    /**
     * The initial velocity of each ball.
     *
     * @return list of velocities.
     */
    public List<Velocity> initialBallVelocities() {
        ArrayList<Velocity> listOfVel = new ArrayList<Velocity>();
        listOfVel.add(Velocity.fromAngleAndSpeed(ANGLE, (double) speed));
        listOfVel.add(Velocity.fromAngleAndSpeed(ANGLE - 48, (double) speed));
        listOfVel.add(Velocity.fromAngleAndSpeed(ANGLE + 48, (double) speed));

        return listOfVel;
    }

    /**
     * The initial of balls locations.
     *
     * @return list of points.
     */
   /* public List<Point> ballLocations() {
        ArrayList<Point> listOfLoc = new ArrayList<Point>();
        for (int i = 0; i < this.numOfBalls; i++) {
            listOfLoc.add(LOC);
        }
        return listOfLoc;

    }*/

    /**
     * Return paddle's speed in current level.
     *
     * @return integer representing paddle's speed.
     */
    public int paddleSpeed() {
        return this.paddleSpeed;
    }

    /**
     * Return paddle's size in current level.
     *
     * @return integer representing paddle's size.
     */
    public int paddleWidth() {
        return this.paddleWidth;
    }

    /**
     * Return current level's name.
     *
     * @return string representing level's name.
     */
    public String levelName() {
        return this.levelName;
    }

    /**
     * Returns a sprite with the background of the level.
     *
     * @return sprite representing level's background.
     */
    public Sprite getBackground() {
        return new Background4();
    }

    /**
     * The initial of the blocks of the current level.
     *
     * @return list of blocks.
     */
    public List<Block> blocks() {
        ArrayList<Block> blocksList = new ArrayList<Block>();
        // Blocks colors
        Color[] color = {Color.GRAY, Color.red, Color.yellow, Color.green, Color.white, Color.pink, Color.cyan};
        for (int i = 0; i < NUM_OF_LINES; i++) {
            for (int k = 0; k < BLOCK_IN_LINE; k++) {
                Point upperLeft = new Point(WIDTH - BOUNDARY_SIZE - (BLOCK_LINE_W * (k + 1)) - 1,
                        90 + (BLOCK_LINE_H * i));
                Block block = new Block(upperLeft, BLOCK_LINE_W, BLOCK_LINE_H, color[i % (color.length)],
                        1);
                blocksList.add(block);
            }
        }
        return blocksList;
    }

    /**
     * Return the number of blocks in the current level.
     *
     * @return integer representing the number of blocks.
     */
    public int numberOfBlocksToRemove() {
        return this.numBlocks;
    }
}
