package sprites;

import java.awt.Color;

import biuoop.DrawSurface;
import geometry.Point;

/**
 * The Background2 class is in charge of the WideEasy's style.
 *
 * @author Dorin Domin.
 */
public class Background2 implements Sprite {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int BOUNDARY_SIZE = 30;
    public static final int SCORE_BLOCK = 20;
    // Fields
    private int size = 70;
    private Point center = new Point(150, 150);

    /**
     * Draw the sprite to the screen.
     *
     * @param d surface do draw on.
     */
    public void drawOn(DrawSurface d) {
        // Draw background
        d.setColor(Color.LIGHT_GRAY);
        d.fillRectangle(BOUNDARY_SIZE, BOUNDARY_SIZE + SCORE_BLOCK, WIDTH - (2 * BOUNDARY_SIZE),
                HEIGHT - BOUNDARY_SIZE);

        // Draw lines
        size -= 12;
        d.setColor(Color.getHSBColor(0.3f, 62f, 0.9f));
        for (int i = 0; i < size; i++) {
            d.drawLine((int) center.getX(), (int) center.getY(), i * 12,
                    (HEIGHT - BOUNDARY_SIZE - SCORE_BLOCK) / 2 + 7);
        }
        size += 12;
        // Draw sun
        d.setColor(Color.getHSBColor(0.28f, 62f, 0.4f));
        d.fillCircle((int) center.getX(), (int) center.getY(), size);
        this.size -= 12;
        d.setColor(Color.getHSBColor(0.3f, 62f, 0.9f));
        d.fillCircle((int) center.getX(), (int) center.getY(), size);
        size -= 12;
        d.setColor(Color.YELLOW);
        d.fillCircle((int) center.getX(), (int) center.getY(), size);
        size += 24;
    }

    /**
     * Notify the sprite that time has passed.
     *
     * @param dt the difference.
     */
    public void timePassed(double dt) {
        // To be updated...
    }
}
