package sprites;

import java.awt.Color;

import biuoop.DrawSurface;
import geometry.Point;

/**
 * The Background1 class is in charge of the DirectHit's style.
 *
 * @author Dorin Domin.
 */
public class Background1 implements Sprite {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int BOUNDARY_SIZE = 30;
    public static final int SCORE_BLOCK = 20;
    // Fields
    private int dif = 30;
    private int radius = 80;
    private Point center = new Point(WIDTH / 2, HEIGHT / 3);

    /**
     * Draw the sprite to the screen.
     *
     * @param d surface do draw on.
     */
    public void drawOn(DrawSurface d) {
        // Draw background
        d.setColor(Color.BLACK);
        d.fillRectangle(BOUNDARY_SIZE, BOUNDARY_SIZE + SCORE_BLOCK, WIDTH - (2 * BOUNDARY_SIZE),
                HEIGHT - BOUNDARY_SIZE);
        // Draw blue circles
        d.setColor(Color.BLUE);
        d.drawCircle((int) center.getX(), (int) center.getY(), radius);
        d.drawCircle((int) center.getX(), (int) center.getY(), radius + dif);
        d.drawCircle((int) center.getX(), (int) center.getY(), radius + dif * 2);
        // Draw blue lines
        d.drawLine(WIDTH / 2, 50, WIDTH / 2, 350);
        d.drawLine(250, HEIGHT / 3, 550, HEIGHT / 3);
    }

    /**
     * Notify the sprite that time has passed.
     *
     * @param dt the difference.
     */
    public void timePassed(double dt) {
        // To be updated...
    }
}
