package sprites;

import biuoop.DrawSurface;
import game.GameLevel;
import geometry.Line;
import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;

import java.awt.Color;

/**
 * The sprites.Paddle program implements an application for a paddle object.
 * sprites.Paddle is the player in the game. It is a rectangle that is controlled by the arrow keys,
 * and moves according to the player key presses.
 * It implements the sprites.Sprite and the sprites.Collidable interfaces.
 * It also knows how to move to the left and to the right.
 *
 * @author Dorin Domin
 */
public class Paddle implements Sprite, Collidable {
    public static final int MIN = 24;

    // Fields
    private biuoop.KeyboardSensor keyboard;
    private Rectangle paddle;
    private java.awt.Color color;
    private int maxLeft;
    private int minLeft;
    private double velocity;

    /**
     * Constructor.
     * <p>
     *
     * @param keyB      key board sensor.
     * @param upperLeft point.
     * @param width     of the paddle.
     * @param height    of the paddle.
     * @param color     of the paddle.
     * @param max       x value for the paddle.
     * @param v         paddle's velocity.
     */
    public Paddle(biuoop.KeyboardSensor keyB, Point upperLeft, int width, int height, java.awt.Color color, int max
            , double v) {
        this.keyboard = keyB;
        this.paddle = new Rectangle(upperLeft, width, height);
        this.color = color;
        this.maxLeft = max - paddle.getWidth();
        this.minLeft = MIN;
        this.velocity = v;
    }

    /**
     * Move paddle to left.
     *
     * @param dt the difference.
     */
    public void moveLeft(double dt) {
        double oldX = paddle.getUpperLeftP().getX();
        double oldY = paddle.getUpperLeftP().getY();
        double newX = oldX - (this.velocity * dt);
        // Move left but don't cross the board
        if (newX <= minLeft) {
            paddle.setUpperLeftP(new Point(minLeft, oldY));
        } else {
            paddle.setUpperLeftP(new Point(newX, oldY));
        }
    }

    /**
     * Move paddle to right.
     *
     * @param dt the difference.
     */
    public void moveRight(double dt) {
        double oldX = paddle.getUpperLeftP().getX();
        double oldY = paddle.getUpperLeftP().getY();
        double newX = oldX + (this.velocity * dt);
        // Move right but don't cross the board
        if (newX >= maxLeft) {
            paddle.setUpperLeftP(new Point(maxLeft, oldY));
        } else {
            paddle.setUpperLeftP(new Point(newX, oldY));
        }
    }

    /**
     * Move paddle on board using keyboard.
     *
     * @param dt the difference.
     */
    @Override
    public void timePassed(double dt) {
        if (keyboard.isPressed(keyboard.LEFT_KEY)) {
            this.moveLeft(dt);
        }
        if (keyboard.isPressed(keyboard.RIGHT_KEY)) {
            this.moveRight(dt);
        }
    }

    /**
     * Draw paddle.
     * <p>
     *
     * @param d surface to draw on.
     */
    @Override
    public void drawOn(DrawSurface d) {
        // Draw paddle on screen
        Point upperLeft = paddle.getUpperLeftP();
        d.setColor(color);
        d.fillRectangle((int) upperLeft.getX(), (int) upperLeft.getY(), paddle.getWidth(),
                paddle.getHeight());
        // Draw a frame
        d.setColor(Color.black);
        d.drawRectangle((int) upperLeft.getX(), (int) upperLeft.getY(), paddle.getWidth(),
                paddle.getHeight());
    }

    /**
     * Get paddle's rectangle.
     * <p>
     *
     * @return a rectangle.
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return this.paddle;
    }

    @Override
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        double dis = paddle.getWidth();
        double len = dis / 5;
        double x = paddle.getUpperLeftP().getX();
        double y = paddle.getUpperLeftP().getY();
        // Divide the paddle to 5 regions
        Line region1 = new Line(x, y, x + len, y);
        Line region2 = new Line(x + len, y, x + len * 2, y);
        Line region3 = new Line(x + len * 2, y, x + len * 3, y);
        Line region4 = new Line(x + len * 3, y, x + len * 4, y);
        Line region5 = new Line(x + len * 4, y, x + len * 5, y);
        Velocity vel = currentVelocity;
        Boolean flag = false;

        // Region1
        if (region1.checkOnLine(collisionPoint)) {
            vel = Velocity.fromAngleAndSpeed(150, currentVelocity.getSpeed());
            flag = true;

        } else if (region2.checkOnLine(collisionPoint)) {
            // Region2
            vel = Velocity.fromAngleAndSpeed(120, currentVelocity.getSpeed());
            flag = true;

        } else if (region3.checkOnLine(collisionPoint)) {
            // Hits the middle - region3
            vel = currentVelocity.changeDyVel();
            flag = true;

        } else if (region4.checkOnLine(collisionPoint)) {
            // Region 4
            vel = Velocity.fromAngleAndSpeed(60, currentVelocity.getSpeed());
            flag = true;

        } else if (region5.checkOnLine(collisionPoint)) {
            // Region 5
            vel = Velocity.fromAngleAndSpeed(30, currentVelocity.getSpeed());
            flag = true;
        }
        // No hit on surface occurred
        if (!flag) {
            // Hits the the height of the block
            if (paddle.getLeftVerticleLine().checkOnLine(collisionPoint)) {
                if (currentVelocity.getYVelocity() > 0) {
                    vel = vel.changeDyVel();
                }
                if (currentVelocity.getXVelocity() > 0) {
                    vel = vel.changeDxVel();
                }
            }
            if (paddle.getRightVerticleLine().checkOnLine(collisionPoint)) {
                if (currentVelocity.getYVelocity() > 0) {
                    vel = vel.changeDyVel();
                }
                if (currentVelocity.getXVelocity() < 0) {
                    vel = vel.changeDxVel();
                }
            }
        }
        return vel;
    }

    /**
     * Add this paddle to the game.
     * <p>
     *
     * @param g a game to add to.
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }

    /**
     * Set paddle x-location.
     *
     * @param loc dauble new x.
     */
    public void setX(double loc) {
        Point newLoc = new Point(loc, this.paddle.getUpperLeftP().getY());
        this.paddle.setUpperLeftP(newLoc);
    }
}