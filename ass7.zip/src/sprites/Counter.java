package sprites;

/**
 * sprites.Counter is a simple class that is used for counting things.
 *
 * @author Dorin Domin
 */
public class Counter {
    // Fields
    private int val;

    /**
     * Constructor.
     *
     * @param num value to update.
     */
    public Counter(int num) {
        this.val = num;
    }

    /**
     * Add number to current count.
     *
     * @param number integer to add.
     */
    public void increase(int number) {
        this.val += number;
    }

    /**
     * Subtract number from current count.
     *
     * @param number integer to add.
     */
    public void decrease(int number) {
        this.val -= number;
    }

    /**
     * Get current count.
     *
     * @return current count.
     */
    public int getValue() {
        return this.val;
    }
}