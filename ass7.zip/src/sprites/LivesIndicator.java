package sprites;

import biuoop.DrawSurface;
import game.GameLevel;
import geometry.Point;

import java.awt.Color;

/**
 * The sprites.LivesIndicator sprite sits at
 * the top of the screen and indicate the number of lives.
 *
 * @author Dorin Domin
 */
public class LivesIndicator implements Sprite {
    // Fields
    private Counter lives;
    private final Point loc = new Point(100, 18);
    private final int fontSize = 18;

    /**
     * Constructor.
     *
     * @param lives indicates how much lives the player has.
     */
    public LivesIndicator(Counter lives) {
        this.lives = lives;
    }

    /**
     * Draw the sprite to the screen.
     *
     * @param d surface do draw on.
     */
    public void drawOn(DrawSurface d) {
        String str = "Lives: " + lives.getValue();
        d.setColor(Color.BLACK);
        d.drawText((int) loc.getX(), (int) loc.getY(), str, fontSize);
    }

    /**
     * Notify the sprite that time has passed.
     *
     * @param dt the difference.
     */
    public void timePassed(double dt) {
    }

    /**
     * Add sprites.LivesIndicator to game.
     *
     * @param g game.
     */
    public void addToGame(GameLevel g) {

        g.addSprite(this);
    }
}
