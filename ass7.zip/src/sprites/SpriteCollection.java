package sprites;

import biuoop.DrawSurface;

import java.util.ArrayList;
import java.util.List;

/**
 * The sprites.SpriteCollection "holds" a collection of sprites.
 *
 * @author Dorin Domin
 */
public class SpriteCollection {

    // Fields
    private List<Sprite> sprites;

    /**
     * Constructor.
     * <p>
     */
    public SpriteCollection() {
        this.sprites = new ArrayList<Sprite>();
    }

    /**
     * Add the given sprite to list.
     * <p>
     *
     * @param s a sprite to add to the collection.
     */
    public void addSprite(Sprite s) {
        this.sprites.add(s);
    }

    /**
     * Remove the given sprite from the list.
     * <p>
     *
     * @param s a sprite to be removed.
     */
    public void removeSprite(Sprite s) {
        this.sprites.remove(s);
    }

    /**
     * Call timePassed() on all sprites.
     *
     * @param dt the difference.
     */
    public void notifyAllTimePassed(double dt) {
        List<Sprite> sp = new ArrayList<Sprite>(this.sprites);
        for (Sprite s : sp) {
            s.timePassed(dt);
        }
    }

    /**
     * Call drawOn(d) on all sprites.
     * <p>
     *
     * @param d a surface to draw on.
     */
    //
    public void drawAllOn(DrawSurface d) {
        for (Sprite s : sprites) {
            s.drawOn(d);
        }
    }
}