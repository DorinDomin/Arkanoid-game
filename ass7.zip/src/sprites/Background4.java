package sprites;

import java.awt.Color;

import biuoop.DrawSurface;

/**
 * The Background4 class is in charge of the FinalFour's style.
 *
 * @author Dorin Domin.
 */
public class Background4 implements Sprite {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int BOUNDARY_SIZE = 30;
    public static final int SCORE_BLOCK = 20;
    public static final int LINES = 10;

    /**
     * Draw the sprite to the screen.
     *
     * @param d surface do draw on.
     */
    public void drawOn(DrawSurface d) {
        // Draw background
        d.setColor(new Color(23, 135, 207));
        d.fillRectangle(BOUNDARY_SIZE, BOUNDARY_SIZE + SCORE_BLOCK, WIDTH - (2 * BOUNDARY_SIZE),
                HEIGHT - BOUNDARY_SIZE);
        // Draw lines
        d.setColor(Color.white);
        for (int i = 0; i < LINES; i++) {
            d.drawLine(130 + (i * 10), 400, 98 + (i * 11), HEIGHT);
        }
        // Draw clouds
        d.setColor(new Color(203, 203, 203));
        d.fillCircle(110, 390, 30);
        d.fillCircle(140, 410, 35);
        d.setColor(new Color(186, 186, 186));
        d.fillCircle(155, 375, 38);
        d.setColor(new Color(169, 169, 169));
        d.fillCircle(210, 380, 40);
        d.fillCircle(180, 410, 28);
        // Draw lines
        d.setColor(Color.white);
        for (int i = 0; i < LINES; i++) {
            d.drawLine(580 + (i * 10), 500, 548 + (i * 10), HEIGHT);
        }
        // Draw clouds
        d.setColor(new Color(203, 203, 203));
        d.fillCircle(560, 490, 30);
        d.fillCircle(585, 532, 35);
        d.setColor(new Color(186, 186, 186));
        d.fillCircle(610, 490, 38);
        d.setColor(new Color(169, 169, 169));
        d.fillCircle(660, 500, 35);
        d.fillCircle(630, 515, 28);
    }

    /**
     * Notify the sprite that time has passed.
     *
     * @param dt the difference.
     */
    public void timePassed(double dt) {
        // To be updated...
    }
}
