package sprites;

import biuoop.DrawSurface;

/**
 * The sprites.Sprite is an interface that includes all parts of the game.
 *
 * @author Dorin Domin
 */
public interface Sprite {
    /**
     * Draw the sprite to the screen.
     *
     * @param d surface do draw on.
     */
    void drawOn(DrawSurface d);

    /**
     * Notify the sprite that time has passed.
     *
     * @param dt the difference.
     */
    void timePassed(double dt);
}