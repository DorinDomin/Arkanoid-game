package sprites;

import biuoop.DrawSurface;
import game.GameLevel;
import geometry.Line;
import geometry.Point;
import geometry.Velocity;

/**
 * The sprites.Ball program implements an application for a ball object.
 * Balls has size (radius), color, and location (a geometry.Point).
 * Balls also know how to draw themselves on a DrawSurface.
 *
 * @author Dorin Domin
 */
public class Ball implements Sprite {
    // Fields
    private Point location;
    private int radius;
    private java.awt.Color color;
    private Velocity vel;
    private int maxX;
    private int maxY;
    private int minLimit;
    private GameEnvironment environment;

    /**
     * Constructor.
     * <p>
     *
     * @param center the center of a ball.
     * @param r      the radius of a ball.
     * @param color  the color of a ball.
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.location = new Point(center.getX(), center.getY());
        this.radius = r;
        this.color = color;
        this.vel = new Velocity();
        // Default values
        setBallLimits(200, 200, 0);
        this.environment = new GameEnvironment();
    }

    /**
     * Constructor.
     * <p>
     *
     * @param x     the x value of a center of a ball.
     * @param y     the y value of a center of a ball.
     * @param r     the radius of a ball.
     * @param color the color of a ball.
     */
    public Ball(int x, int y, int r, java.awt.Color color) {
        this.location = new Point(x, y);
        this.radius = r;
        this.color = color;
        this.vel = new Velocity();
        this.environment = new GameEnvironment();
        // Default
        setBallLimits(800, 600, 50);

    }

    /**
     * Allows access to the x value of the center of ball.
     * <p>
     *
     * @return x value of ball.
     */
    public int getX() {
        return (int) this.location.getX();
    }

    /**
     * Allows access to the y value of the center of ball.
     * <p>
     *
     * @return y value of ball.
     */
    public int getY() {
        return (int) this.location.getY();
    }

    /**
     * Allows access to size of ball.
     * <p>
     *
     * @return size of ball.
     */
    public int getSize() {
        return this.radius;
    }

    /**
     * Allows access to the color of ball.
     * <p>
     *
     * @return color of ball.
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * Allows access to velocity of ball.
     * <p>
     *
     * @return velocity of ball.
     */
    public Velocity getVelocity() {
        return this.vel;
    }

    /**
     * Assignment to limits of a ball.
     * <p>
     *
     * @param maxXVal int value for maximum x value.
     * @param maxYVal int value for maximum y value.
     * @param min     int value for minimum values.
     */
    public void setBallLimits(int maxXVal, int maxYVal, int min) {
        this.maxX = maxXVal;
        this.maxY = maxYVal;
        this.minLimit = min;
    }

    /**
     * Assignment to the velocity of a ball.
     * <p>
     *
     * @param v velocity of a ball.
     */
    public void setVelocity(Velocity v) {
        this.vel = v;
    }

    /**
     * Assignment to the velocity of a ball.
     * <p>
     *
     * @param dx X axis change of a ball.
     * @param dy Y axis change of a ball.
     */
    public void setVelocity(double dx, double dy) {
        this.vel = new Velocity(dx, dy);
    }

    /**
     * Assignment to the GameEvironment of a ball.
     * <p>
     *
     * @param e a game environment of a ball.
     */
    public void setGameEvironment(GameEnvironment e) {
        this.environment = e;
    }

    /**
     * Draw the ball on the given DrawSurface.
     * <p>
     *
     * @param surface use to draw on the screen.
     */
    @Override
    public void drawOn(DrawSurface surface) {
        // Set color and fill circle
        surface.setColor(this.getColor());
        surface.fillCircle(this.getX(), this.getY(), this.radius);
        surface.setColor(java.awt.Color.BLACK);
        surface.drawCircle(this.getX(), this.getY(), this.radius);
    }

    /**
     * Update ball's location due to hit point and velocity.
     * <p>
     *
     * @param target a collisionInfo.
     * @param newVel velocity object.
     */
    public void updateLocation(CollisionInfo target, Velocity newVel) {
        // Set target as new location for the ball
        double newX = target.collisionPoint().getX();
        double newY = target.collisionPoint().getY();
        // Flags for changes in x and y
        boolean flagX = false;
        boolean flagY = false;

        // Case hit the same vertex again
        if (!this.vel.ifChangedDx(newVel.getXVelocity())
                && !this.vel.ifChangedDy(newVel.getYVelocity())) {
            flagX = true;
        }
        // There is a change in X axis
        if (this.vel.ifChangedDx(newVel.getXVelocity())) {
            // Hits an upper vertex from left to right or a down-left vertex from left to right
            if (location.getX() < newX && location.getY() < newY) {
                flagY = true;
            }
            // Hits an upper-right vertex from down-up or a left-down vertex from right-to-left
            if (location.getX() > newX && location.getY() < newY) {
                flagY = true;
            }
            // Hits a left upper vertex from down-up
            if (location.getX() < newX && location.getY() > newY) {
                flagY = true;

            }
        }
        // There is a change in Y axis
        if (this.vel.ifChangedDy(newVel.getYVelocity())) {
            // Hits an upper left vertex from right to left
            if (location.getX() < newX && location.getY() < newY) {
                flagX = true;
            }
            // Hits a down-left vertex from right to left
            if (location.getX() > newX && location.getY() > newY) {
                flagX = true;
            }
            // Hits left-down vertex from left-to-right
            if (location.getX() < newX && location.getY() > newY) {
                flagX = true;
            }
            // Hits an upper-right vertex from upper-right-to-down-left
            if (location.getX() > newX && location.getY() < newY) {
                flagX = true;
            }
        }
        // If flag, keep the old location of the ball
        if (flagX) {
            newX = location.getX();
        }
        if (flagY) {
            newY = location.getY();
        }
        // Case hit the same vertex, update location with radius
        if (!this.vel.ifChangedDx(newVel.getXVelocity())
                && !this.vel.ifChangedDy(newVel.getYVelocity())) {
            // If no change occurred in X axis
            if (!flagX) {
                if (newVel.getXVelocity() > 0) {
                    newX += radius;
                } else {
                    newX -= radius;
                }
            }
            // If no change occurred in Y axis
            if (!flagY) {
                if (newVel.getYVelocity() > 0) {
                    newY += radius;
                } else {
                    newY -= radius;
                }
            }
        }
        // There is a change in Y axis
        if (this.vel.ifChangedDy(newVel.getYVelocity()) && !flagY) {
            if (newVel.getYVelocity() > 0) {
                newY += radius;
            } else {
                newY -= radius;
            }
        }
        // There is a change in X axis
        if (this.vel.ifChangedDx(newVel.getXVelocity()) && !flagX) {
            if (newVel.getXVelocity() > 0) {
                newX += radius;
            } else {
                newX -= radius;
            }

        }
        this.location.setX(newX);
        this.location.setY(newY);
    }

    /**
     * Check if the given x on the ball's limits.
     *
     * @param x type double.
     * @return true if x on limits,false otherwise.
     */
    public boolean checkOnXLimits(double x) {
        if (this.getVelocity().getXVelocity() > 0) {
            return (x <= this.minLimit);
        }
        return (x >= this.maxX);
    }

    /**
     * Check if the given y on the ball's limits.
     *
     * @param y type double.
     * @return true if y on limits,false otherwise.
     */
    public boolean checkOnYLimits(double y) {
        if (this.getVelocity().getYVelocity() > 0) {
            return (y <= this.minLimit);
        }
        return (y >= this.maxY);
    }

    /**
     * Check if point on limits.
     *
     * @param point to check.
     * @return true if points on limits, false otherwise.
     */
    public boolean onBallLimits(Point point) {
        // Check if point on board limits
        double x = point.getX();
        double y = point.getY();
        // Check on limits
        return checkOnXLimits(x) || checkOnYLimits(y);
    }

    /**
     * Determination of movement of the ball.
     *
     * @param dt difference.
     */
    public void moveOneStep(double dt) {
        // Create ball's route
        Point target = getVelocity().applyToPoint(this.location, dt);
        Line trajectory = new Line(this.location, target);
        CollisionInfo closestColli = environment.nextColli(trajectory, getSize());
        // Check board limits
        if (closestColli != null) {
            Velocity newVel = closestColli.collisionObject().hit(this, closestColli.collisionPoint(), this.vel);
            //  Move the ball to "almost" the hit point
            this.updateLocation(closestColli, newVel);
            this.setVelocity(newVel);

        } else {
            // Include radius in ball's route
            includeRadius(target);
        }
    }

    /**
     * determine current ball's next move and location including radius.
     * <p>
     *
     * @param target type point.
     */
    public void includeRadius(Point target) {
        // Calculate next location with radius
        double newX = target.getX() + getSize();
        double newX2 = target.getX() - getSize();
        double newY = target.getY() + getSize();
        double newY2 = target.getY() - getSize();

        // Check trajectory with radius
        Point targetX = new Point(newX, target.getY());
        Point targetY = new Point(target.getX(), newY);
        Point targetX2 = new Point(newX2, target.getY());
        Point targetY2 = new Point(target.getX(), newY2);

        Line xRadiusT = new Line(target, targetX);
        Line yRadiusT = new Line(target, targetY);
        Line xRadiusT2 = new Line(target, targetX2);
        Line yRadiusT2 = new Line(target, targetY2);

        // Find closest collision
        CollisionInfo xColl = environment.getClosestCollision(xRadiusT);
        CollisionInfo yColl = environment.getClosestCollision(yRadiusT);
        CollisionInfo xColl2 = environment.getClosestCollision(xRadiusT2);
        CollisionInfo yColl2 = environment.getClosestCollision(yRadiusT2);
        if (xColl != null) {
            Velocity newVel = xColl.collisionObject().hit(this, xColl.collisionPoint(), this.vel);
            //  Move the ball to "almost" the hit point
            this.updateLocation(xColl, newVel);
            this.setVelocity(newVel);
        } else if (yColl != null) {
            Velocity newVel = yColl.collisionObject().hit(this, yColl.collisionPoint(), this.vel);
            //  Move the ball to "almost" the hit point
            this.updateLocation(yColl, newVel);
            this.setVelocity(newVel);
        } else if (xColl2 != null) {
            Velocity newVel = xColl2.collisionObject().hit(this, xColl2.collisionPoint(), this.vel);
            //  Move the ball to "almost" the hit point
            this.updateLocation(xColl2, newVel);
            this.setVelocity(newVel);
        } else if (yColl2 != null) {
            Velocity newVel = yColl2.collisionObject().hit(this, yColl2.collisionPoint(), this.vel);
            //  Move the ball to "almost" the hit point
            this.updateLocation(yColl2, newVel);
            this.setVelocity(newVel);
        } else {
            this.location = target;
        }
    }

    /**
     * Move ball to the next step.
     * <p>
     *
     * @param dt difference.
     */
    @Override
    public void timePassed(double dt) {
        this.moveOneStep(dt);
    }

    /**
     * Add ball to the game.
     * <p>
     *
     * @param g the game to add to.
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }

    /**
     * Remove ball from gameLevel.
     * <p>
     *
     * @param gameLevel to be updated.
     */
    public void removeFromGame(GameLevel gameLevel) {
        gameLevel.removeSprite(this);
    }

}


