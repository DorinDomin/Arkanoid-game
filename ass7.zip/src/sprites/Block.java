package sprites;

import biuoop.DrawSurface;
import game.GameLevel;
import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;
import listeners.HitListener;

import java.awt.Color;
import java.awt.Image;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

/**
 * The sprites.Block program implements an application for a block object.
 * Blocks are rectangles,with colors and a number of hit points.
 * Blocks also know how to draw themselves on a DrawSurface.
 *
 * @author Dorin Domin
 */
public class Block implements Collidable, Sprite, HitNotifier {
    // Fields
    private Rectangle block;
    private java.awt.Color strokeColor;
    private int hitPoints;
    private List<HitListener> hitListeners;
    private HashMap<Integer, Color> mapClr;
    private HashMap<Integer, Image> mapImg;

    /**
     * Constructor.
     * <p>
     *
     * @param upperLeft start point of the rectangle (of the block).
     * @param width     of the rectangle (of the block).
     * @param height    of the rectangle (of the block).
     * @param color     of the rectangle (of the block).
     * @param hitN      positive number of hits.
     */
    public Block(Point upperLeft, int width, int height, java.awt.Color color, int hitN) {
        this.block = new Rectangle(upperLeft, width, height);
        this.strokeColor = color;
        this.hitPoints = hitN;
        this.hitListeners = new LinkedList<>();
        this.mapClr = new HashMap<Integer, Color>();
        this.mapImg = new HashMap<Integer, Image>();
    }

    /**
     * Return the shape.
     *
     * @return rectangle.
     */
    @Override
    public Rectangle getCollisionRectangle() {
        return this.block;
    }

    /**
     * Notify the block about that a collision occurred.
     * Update the velocity to the new velocity.
     * <p>
     *
     * @param collisionPoint  where the collision occurred.
     * @param currentVelocity current velocity of the ball.
     * @param hitter          ball.
     * @return new velocity.
     */
    @Override
    public Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity) {
        // When a ball hits the block, the number of hit-points should decrease
        decreaseHitPoints();
        // Notifiers all of the registered listeners.HitListener objects by calling their hitEvent method
        this.notifyHit(hitter);
        Velocity vertexVel = velByVertex(collisionPoint, currentVelocity);
        // Check vertices hit
        if (vertexVel == null) {
            Velocity newVel = currentVelocity;
            // Check if hits the the width of the block
            if (block.getDownParallelLine().checkOnLine(collisionPoint)
                    || block.getUpperParallelLine().checkOnLine(collisionPoint)) {
                newVel = newVel.changeDyVel();
            }
            // Hits the the height of the block
            if (block.getRightVerticleLine().checkOnLine(collisionPoint)
                    || block.getLeftVerticleLine().checkOnLine(collisionPoint)) {
                newVel = newVel.changeDxVel();
            }
            return newVel;
        }
        return vertexVel;
    }

    /**
     * Return the color of the block.
     * <p>
     *
     * @return Color.
     */
    public java.awt.Color getColor() {
        return this.strokeColor;
    }

    /**
     * Draw block on surface.
     * <p>
     *
     * @param surface to draw on.
     */
    @Override
    public void drawOn(DrawSurface surface) {
        Point upperLeft = block.getUpperLeftP();
        // Check if defined image for current num of points
        if (this.mapImg.containsKey(this.hitPoints)) {
            surface.drawImage((int) upperLeft.getX(), (int) upperLeft.getY(), this.mapImg.get(this.hitPoints));
        } else if (this.mapClr.containsKey(this.hitPoints)) {
            // Check if defined color for current num of points
            surface.setColor(this.mapClr.get(this.hitPoints));
            surface.fillRectangle((int) upperLeft.getX(), (int) upperLeft.getY(), block.getWidth(),
                    block.getHeight());
        } else if (this.mapImg.containsKey(-1)) {
            surface.drawImage((int) upperLeft.getX(), (int) upperLeft.getY(), this.mapImg.get(-1));
        } else {
            surface.setColor(this.mapClr.get(-1));
            surface.fillRectangle((int) upperLeft.getX(), (int) upperLeft.getY(), block.getWidth(),
                    block.getHeight());
        }
        // Check if defined stroke
        if (this.strokeColor != null) {
            surface.setColor(this.strokeColor);
            surface.drawRectangle((int) upperLeft.getX(), (int) upperLeft.getY(), block.getWidth(), block.getHeight());
        }
    }

    /**
     * Notify the block.
     *
     * @param dt the difference.
     */
    @Override
    public void timePassed(double dt) {

    }

    /**
     * Add block to game.
     * <p>
     *
     * @param g game to add to.
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
        g.addCollidable(this);
    }

    /**
     * Remove block from gameLevel.
     * <p>
     *
     * @param gameLevel to be updated.
     */
    public void removeFromGame(GameLevel gameLevel) {
        gameLevel.removeSprite(this);
        gameLevel.removeCollidable(this);
    }

    /**
     * adds image to image map.
     *
     * @param key integer.
     * @param img java.awt.Image.
     */
    public void addImg(int key, Image img) {
        this.mapImg.put(key, img);
    }

    /**
     * adds color to color map.
     *
     * @param key integer.
     * @param clr java.awt.Color.
     */
    public void addClr(int key, Color clr) {
        this.mapClr.put(key, clr);
    }

    /**
     * sets colors map to inputed one.
     *
     * @param input **numbers to colors map**
     */
    public void setMapClr(HashMap<Integer, Color> input) {
        this.mapClr = input;
    }

    /**
     * sets images map to inputed one.
     *
     * @param input **numbers to images map**
     */
    public void setMapImg(HashMap<Integer, Image> input) {
        this.mapImg = input;
    }

    /**
     * Add h1 as listener.
     * <p>
     *
     * @param hl to add to listener list.
     */
    public void addHitListener(HitListener hl) {
        this.hitListeners.add(hl);
    }

    /**
     * Remove h1 as listener.
     * <p>
     *
     * @param hl to be removed from listener list.
     */
    public void removeHitListener(HitListener hl) {
        this.hitListeners.remove(hl);
    }

    /**
     * Return the number of hit points.
     *
     * @return an integer.
     */
    public int getHitPoints() {
        return this.hitPoints;
    }

    /**
     * Determine the number of hit points.
     *
     * @param num an integer.
     */
    public void setHitPoints(int num) {
        this.hitPoints = num;
    }

    /**
     * Update number of hit points after hit.
     * <p>
     */
    public void decreaseHitPoints() {
        int hitsNum = getHitPoints();
        if (hitsNum > 0) {
            setHitPoints(hitsNum - 1);
        }
    }

    /**
     * Determine ball's new vel after hitting a vertex.
     * <p>
     *
     * @param vertex  closest vertex to ball.
     * @param current type velocity.
     * @return new velocity.
     */
    public Velocity velByVertex(Point vertex, Velocity current) {
        Velocity newVel = current;
        boolean flag = false;
        // Update  vel according to the block's vertices
        if (vertex.equals(block.getUpperLeftP())) {
            if (current.getXVelocity() > 0) {
                newVel = newVel.changeDxVel();
            }
            if (current.getYVelocity() > 0) {
                newVel = newVel.changeDyVel();
            }
            flag = true;
        } else if (vertex.equals(block.getDownLeftP())) {
            if (current.getXVelocity() > 0) {
                newVel = newVel.changeDxVel();
            }
            if (current.getYVelocity() < 0) {
                newVel = newVel.changeDyVel();
            }
            flag = true;
        } else if (vertex.equals(block.getUpperRightP())) {
            if (current.getXVelocity() < 0) {
                newVel = newVel.changeDxVel();
            }
            if (current.getYVelocity() > 0) {
                newVel = newVel.changeDyVel();
            }
            flag = true;
        } else if (vertex.equals(block.getUpperRightP())) {
            if (current.getXVelocity() < 0) {
                newVel = newVel.changeDxVel();
            }
            if (current.getYVelocity() > 0) {
                newVel = newVel.changeDyVel();
            }
            flag = true;
        } else if (vertex.equals(block.getDownRightP())) {
            if (current.getXVelocity() < 0) {
                newVel = newVel.changeDxVel();
            }
            if (current.getYVelocity() < 0) {
                newVel = newVel.changeDyVel();
            }
            flag = true;
        }
        // No change was needed
        if (newVel.getXVelocity() == current.getXVelocity()
                && newVel.getYVelocity() == current.getYVelocity() && !flag) {
            return null;
        }
        return newVel;

    }

    /**
     * Notifiers all of the registered listeners.HitListener objects
     * by calling their hitEvent method.
     *
     * @param hitter ball.
     */
    private void notifyHit(Ball hitter) {
        // Make a copy of the hitListeners before iterating over them.
        List<HitListener> listeners = new ArrayList<HitListener>(this.hitListeners);
        // Notify all listeners about a hit event:
        for (HitListener hl : listeners) {
            hl.hitEvent(this, hitter);
        }
    }
}

