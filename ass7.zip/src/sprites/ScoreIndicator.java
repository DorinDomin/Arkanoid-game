package sprites;

import biuoop.DrawSurface;
import game.GameLevel;
import geometry.Point;

import java.awt.Color;

/**
 * The sprites.ScoreIndicator sprite sits at
 * the top of the screen and in charge of displaying the current score.
 *
 * @author Dorin Domin
 */
public class ScoreIndicator implements Sprite {
    // Fields
    private Counter score;
    private final int fontSize = 18;
    private Point textLocation = new Point(300, 18);


    /**
     * Constructor.
     *
     * @param scores players scores.
     */
    public ScoreIndicator(Counter scores) {
        this.score = scores;
    }

    /**
     * Draw the sprite to the screen.
     *
     * @param d surface do draw on.
     */
    public void drawOn(DrawSurface d) {
        // Show text on the white block
        String str = "Score: " + score.getValue();
        d.setColor(Color.BLACK);
        d.drawText((int) this.textLocation.getX(), (int) this.textLocation.getY(), str, fontSize);
    }

    /**
     * Notify the sprite that time has passed.
     *
     * @param dt the difference.
     */
    public void timePassed(double dt) {
    }

    /**
     * Add sprites.ScoreIndicator to game.
     *
     * @param g game.
     */
    public void addToGame(GameLevel g) {

        g.addSprite(this);
    }
}
