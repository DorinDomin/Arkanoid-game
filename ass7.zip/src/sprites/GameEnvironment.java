package sprites;

import geometry.Line;
import geometry.Point;
import geometry.Rectangle;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 * The sprites.GameEnvironment class in a collection of objects a sprites.Ball can collide with.
 * The ball will know the game environment, and will use it to check
 * for collisions and direct its movement.
 *
 * @author Dorin Domin
 */
public class GameEnvironment {

    // Fields
    private List<Collidable> collidables;

    /**
     * Constructor.
     * <p>
     */
    public GameEnvironment() {
        this.collidables = new ArrayList<Collidable>();
    }

    /**
     * Add the given collidable to the environment.
     * <p>
     *
     * @param c collidable object to add.
     */
    public void addCollidable(Collidable c) {
        this.collidables.add(c);
    }

    /**
     * Remove the given collidable from the environment.
     * <p>
     *
     * @param c collidable object to be removed.
     */
    public void removeCollidable(Collidable c) {
        this.collidables.remove(c);
    }

    /**
     * Assume an object moving from line.start() to line.end().
     * If this object will not collide with any of the collidables
     * in this collection, return null. Else, return the information
     * about the closest collision that is going to occur.
     * <p>
     *
     * @param trajectory a line describes the ball route.
     * @return sprites.CollisionInfo about the closest collision.
     */
    public CollisionInfo getClosestCollision(Line trajectory) {
        Point inter;
        Rectangle r;

        // Create a list of collisions info
        List<CollisionInfo> collisions = new ArrayList<CollisionInfo>();
        // Find collidables on trajectory
        for (Collidable c : collidables) {
            r = c.getCollisionRectangle();
            // Find closest intersection with current collidable
            inter = trajectory.closestIntersectionToStartOfLine(r);
            // Find vertices close to location
            if (inter != null) {
                collisions.add(new CollisionInfo(inter, c));
            }
        }
        return findClosestInList(collisions, trajectory.start());
    }

    /**
     * Find closest collision to a given point in a given list.
     * <p>
     *
     * @param coll  a list of collisions.
     * @param start a point to find closest collision to.
     * @return collisionInfo of the closest collision in the given list.
     */
    public CollisionInfo findClosestInList(List<CollisionInfo> coll, Point start) {
        if (coll.isEmpty()) {
            return null;
        }
        // Iterate thought list
        Iterator<CollisionInfo> iterator = coll.iterator();
        CollisionInfo closest = iterator.next();
        // Compare and find closest collision
        while (iterator.hasNext()) {
            closest = closest.closestCollision(iterator.next(), start);
        }
        return closest;
    }

    /**
     * Find and return the closest vertex by radius to a given location.
     * <p>
     *
     * @param location to find closest collision to.
     * @param radius   the distance.
     * @return closest collision info.
     */
    public CollisionInfo closestVertices(Point location, int radius) {
        Point inter;
        Rectangle r;

        // Create a list closest vertices
        List<CollisionInfo> vertices = new ArrayList<>();
        // Find vertices close to location
        for (Collidable c : collidables) {
            r = c.getCollisionRectangle();
            inter = r.closestVertex(location, radius);
            if (inter != null) {
                vertices.add(new CollisionInfo(inter, c));
            }
        }
        return findClosestInList(vertices, location);

    }

    /**
     * Find closest collision with collidables,including vertices.
     *
     * @param trajectory the route on the ball.
     * @param radius     of the ball.
     * @return collision info of the next collision.
     */
    public CollisionInfo nextColli(Line trajectory, int radius) {
        // Find closest collision with collidables
        CollisionInfo colli = getClosestCollision(trajectory);
        // Find closest collision with vertex
        CollisionInfo vertex = closestVertices(trajectory.start(), radius);
        // Compare and return the closest to trajectory
        if (colli == null && vertex == null) {
            return null;
        }
        if (colli == null && vertex != null) {
            return vertex;
        }
        if (vertex == null && colli != null) {
            return colli;
        }
        if (vertex.collisionPoint().getX() == colli.collisionPoint().getX()
                || vertex.collisionPoint().getY() == colli.collisionPoint().getY()) {
            return vertex;
        }
        return colli.closestCollision(vertex, trajectory.start());
    }
}
