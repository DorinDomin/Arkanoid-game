package sprites;

import geometry.Point;

/**
 * The sprites.CollisionInfo program holds the information about collisions
 * in the game.
 * A collision occurs in a point and with an object.
 *
 * @author Dorin Domin
 */
public class CollisionInfo {
    // Fields
    private Point collisionP;
    private Collidable object;

    /**
     * Constructor.
     * <p>
     *
     * @param collPoint the point where the collision occurred.
     * @param shape     the collidable object.
     */
    public CollisionInfo(Point collPoint, Collidable shape) {
        this.collisionP = new Point(collPoint.getX(), collPoint.getY());
        this.object = shape;
    }

    /**
     * Return the point at which the collision occurs.
     * <p>
     *
     * @return collision point.
     */
    public Point collisionPoint() {
        return this.collisionP;
    }

    /**
     * Return the collidable object involved in the collision.
     * <p>
     *
     * @return collidable object.
     */
    public Collidable collisionObject() {
        return this.object;
    }

    /**
     * Return the closest collision to a given point between two collisions.
     *
     * @param other  another collision.
     * @param target point.
     * @return closest collision to target between other and this.
     */
    public CollisionInfo closestCollision(CollisionInfo other, Point target) {
        // Check for null values
        if (other == null && this == null) {
            return null;
        }
        if (other == null) {
            return this;
        }
        if (this == null) {
            return other;
        }
        // Get closest collision point
        Point coll = target.closestPoint(collisionP, other.collisionPoint());
        if (collisionP.equals(coll)) {
            return this;
        }
        return other;
    }
}