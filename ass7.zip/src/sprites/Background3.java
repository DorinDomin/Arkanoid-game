package sprites;

import biuoop.DrawSurface;
import geometry.Point;

import java.awt.Color;

/**
 * The Background3 class is in charge of the Green3's style.
 *
 * @author Dorin Domin.
 */
public class Background3 implements Sprite {
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    public static final int BOUNDARY_SIZE = 30;
    public static final int SCORE_BLOCK = 20;
    public static final int LINES = 5;
    // Fields
    private int blockHeight = 150;
    private int blockWidth = 120;
    private Point loc = new Point(80, HEIGHT - blockHeight);

    /**
     * Draw the sprite to the screen.
     *
     * @param d surface do draw on.
     */
    public void drawOn(DrawSurface d) {
        // Draw background
        Color back = new Color(42, 129, 21);
        d.setColor(back);
        d.fillRectangle(BOUNDARY_SIZE, BOUNDARY_SIZE + SCORE_BLOCK, WIDTH - (2 * BOUNDARY_SIZE),
                HEIGHT - BOUNDARY_SIZE);
        // Draw tower
        d.setColor(Color.black);
        d.fillRectangle((int) this.loc.getX(), (int) this.loc.getY(), this.blockWidth,
                this.blockHeight);
        // Draw lines
        d.setColor(Color.white);
        for (int i = 0; i < LINES; i++) {
            for (int j = 0; j < LINES; j++) {
                d.fillRectangle((int) this.loc.getX() + (j * 20) + 15, (int) this.loc.getY() + (i * 38) + 15,
                        10, 28);
            }
        }
        // Draw clouds
        d.setColor(new Color(62, 58, 57));
        d.fillRectangle((int) this.loc.getX() + 46, (int) this.loc.getY() - 70, 30, 70);
        d.setColor(new Color(78, 74, 73));
        d.fillRectangle((int) this.loc.getX() + 56, (int) this.loc.getY() - 240, 10, 170);
        d.setColor(Color.orange);
        d.fillCircle((int) this.loc.getX() + 60, (int) this.loc.getY() - 252, 14);
        d.setColor(Color.RED);
        d.fillCircle((int) this.loc.getX() + 60, (int) this.loc.getY() - 252, 10);
        d.setColor(Color.WHITE);
        d.fillCircle((int) this.loc.getX() + 60, (int) this.loc.getY() - 252, 4);

    }

    /**
     * Notify the sprite that time has passed.
     *
     * @param dt the difference.
     */
    public void timePassed(double dt) {
        // To be updated...
    }
}

