package sprites;

import geometry.Point;
import geometry.Rectangle;
import geometry.Velocity;

/**
 * The sprites.Collidable is an interface that will be used by things that can be collided with.
 * (Blocks and paddle).
 *
 * @author Dorin Domin
 */
public interface Collidable {

    /**
     * Return the "collision shape" of the object.
     * <p>
     *
     * @return shape.
     */
    Rectangle getCollisionRectangle();

    /**
     * Notify the object that we collided with it at collisionPoint with
     * a given velocity.
     * The return is the new velocity expected after the hit (based on
     * the force the object inflicted on us).
     *
     * @param collisionPoint  where the collision occurred.
     * @param currentVelocity current velocity of the ball.
     * @param hitter          ball.
     * @return new velocity for the ball.
     */
    Velocity hit(Ball hitter, Point collisionPoint, Velocity currentVelocity);
}