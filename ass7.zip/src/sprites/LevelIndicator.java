package sprites;

import game.GameLevel;
import biuoop.DrawSurface;
import geometry.Point;

import java.awt.Color;

/**
 * The LevelIndicator sprite sits at
 * the top of the screen and in charge of displaying the current level's name.
 *
 * @author Dorin Domin
 */
public class LevelIndicator implements Sprite {
    private String name;
    private final Point loc = new Point(490, 18);
    private final int fontSize = 18;

    /**
     * LevelIndicator object constructor.
     *
     * @param str **String**
     */
    public LevelIndicator(String str) {
        this.name = str;
    }

    /**
     * draws LevelIndicator on surface.
     *
     * @param d **surface to draw on**
     */
    public void drawOn(DrawSurface d) {
        String str = "Level Name: " + this.name;
        d.setColor(Color.BLACK);
        d.drawText((int) loc.getX(), (int) loc.getY(), str, fontSize);
    }

    /**
     * adds LevelIndicator to game.
     *
     * @param g **game**
     */
    public void addToGame(GameLevel g) {
        g.addSprite(this);
    }

    /**
     * Notify the sprite that time has passed.
     *
     * @param dt the difference.
     */
    public void timePassed(double dt) {
        //to be updated...
    }
}